#pragma once
#include <string>
#include <memory>
#include "../database/DatabaseConnection.h"
#include "../models/Booking.h"
#include "CommitManager.h"
#include "RollbackManager.h"

namespace synccore {
namespace transaction {

enum class StepStatus {
    NOT_STARTED,
    RUNNING,
    SUCCESS,
    FAILED
};

struct TransactionStepEvent {
    std::string stepName;
    StepStatus status;
    std::string details;
    long long timestampMs;
};

class TransactionService {
public:
    explicit TransactionService(std::shared_ptr<database::DatabaseConnection> conn);

    models::Transaction recordTransaction(int bookingId, double amount, const std::string& method, bool success);
    models::Transaction getTransactionByBookingId(int bookingId);

private:
    std::shared_ptr<database::DatabaseConnection> conn_;
    std::unique_ptr<CommitManager> commitMgr_;
    std::unique_ptr<RollbackManager> rollbackMgr_;
};

} // namespace transaction
} // namespace synccore
