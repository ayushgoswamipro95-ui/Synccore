#pragma once
#include <memory>
#include <string>
#include "../database/DatabaseConnection.h"

namespace synccore {
namespace transaction {

class CommitManager {
public:
    explicit CommitManager(std::shared_ptr<database::DatabaseConnection> conn);
    bool executeCommit(int bookingId);
};

} // namespace transaction
} // namespace synccore
