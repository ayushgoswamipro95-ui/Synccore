#pragma once
#include <memory>
#include <string>
#include "../database/DatabaseConnection.h"

namespace synccore {
namespace transaction {

class RollbackManager {
public:
    explicit RollbackManager(std::shared_ptr<database::DatabaseConnection> conn);
    bool executeRollback(int bookingId, const std::string& reason);
};

} // namespace transaction
} // namespace synccore
