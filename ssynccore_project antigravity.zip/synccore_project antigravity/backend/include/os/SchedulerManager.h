#pragma once
#include "Process.h"
#include <string>
#include <vector>

namespace synccore {
namespace os {

class IScheduler {
public:
    virtual ~IScheduler() = default;
    virtual std::string getName() const = 0;
    virtual std::vector<Process> schedule(const std::vector<Process>& processes) = 0;
};

class FCFSScheduler : public IScheduler {
public:
    std::string getName() const override { return "FCFS"; }
    std::vector<Process> schedule(const std::vector<Process>& processes) override;
};

class SJFScheduler : public IScheduler {
public:
    std::string getName() const override { return "SJF"; }
    std::vector<Process> schedule(const std::vector<Process>& processes) override;
};

class PriorityScheduler : public IScheduler {
public:
    std::string getName() const override { return "PRIORITY"; }
    std::vector<Process> schedule(const std::vector<Process>& processes) override;
};

class SchedulerManager {
public:
    static SchedulerManager& getInstance() {
        static SchedulerManager instance;
        return instance;
    }

    std::shared_ptr<IScheduler> getScheduler(const std::string& name);

private:
    SchedulerManager();
    std::shared_ptr<FCFSScheduler> fcfs_;
    std::shared_ptr<SJFScheduler> sjf_;
    std::shared_ptr<PriorityScheduler> priority_;
};

} // namespace os
} // namespace synccore
