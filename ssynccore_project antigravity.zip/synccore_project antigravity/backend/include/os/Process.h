#pragma once
#include "../models/Process.h"
#include <memory>
#include <vector>

namespace synccore {
namespace os {

using Process = models::Process;
using ProcessState = models::ProcessState;

class ProcessControlBlock {
public:
    explicit ProcessControlBlock(const Process& proc) : data_(proc) {}
    
    Process& getData() { return data_; }
    const Process& getData() const { return data_; }

    void setState(ProcessState state) { data_.state = state; }
    void decrementRemainingTime(int delta = 1) { 
        data_.remainingTime = (data_.remainingTime > delta) ? (data_.remainingTime - delta) : 0; 
    }

private:
    Process data_;
};

} // namespace os
} // namespace synccore
