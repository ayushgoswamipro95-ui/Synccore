#pragma once
#include "SchedulerManager.h"

namespace synccore {
namespace os {

// Schedulers are declared in SchedulerManager.h

} // namespace os
} // namespace synccore
