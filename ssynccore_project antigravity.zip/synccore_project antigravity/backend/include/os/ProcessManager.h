#pragma once
#include "Process.h"
#include "ReadyQueue.h"
#include "../concurrency/SyncMutex.h"
#include <map>
#include <memory>
#include <vector>

namespace synccore {
namespace os {

class ProcessManager {
public:
    static ProcessManager& getInstance() {
        static ProcessManager instance;
        return instance;
    }

    Process createProcess(const std::string& name, const std::string& runId, int burstTime, int priority, const std::string& seatLabel);
    bool updateProcessState(int processId, ProcessState state);
    bool getProcess(int processId, Process& outProc) const;
    std::vector<Process> getAllProcesses() const;
    void reset();

private:
    ProcessManager() : nextPid_(1) {}
    mutable concurrency::SyncMutex mutex_;
    int nextPid_;
    std::map<int, Process> processes_;
};

} // namespace os
} // namespace synccore
