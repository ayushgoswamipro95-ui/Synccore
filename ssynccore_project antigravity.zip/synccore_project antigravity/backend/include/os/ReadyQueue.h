#pragma once
#include "Process.h"
#include "../concurrency/SyncMutex.h"
#include <deque>
#include <vector>

namespace synccore {
namespace os {

class ReadyQueue {
public:
    ReadyQueue() = default;

    void push(const Process& proc);
    bool pop(Process& outProc);
    bool peek(Process& outProc) const;
    bool empty() const;
    size_t size() const;
    void clear();

    std::vector<Process> getAll() const;

private:
    mutable concurrency::SyncMutex mutex_;
    std::deque<Process> queue_;
};

} // namespace os
} // namespace synccore
