#pragma once
#include <string>

namespace synccore {
namespace models {

enum class LockState {
    FREE,
    REQUESTED,
    ACQUIRED,
    WAITING,
    RELEASED
};

inline std::string lockStateToString(LockState state) {
    switch (state) {
        case LockState::FREE: return "FREE";
        case LockState::REQUESTED: return "REQUESTED";
        case LockState::ACQUIRED: return "ACQUIRED";
        case LockState::WAITING: return "WAITING";
        case LockState::RELEASED: return "RELEASED";
        default: return "FREE";
    }
}

struct ResourceLock {
    int lockId = 0;
    std::string resourceType = "SHOW_SEAT";
    std::string resourceIdentifier; // e.g., "G10"
    LockState state = LockState::FREE;
    int holdingProcessId = 0;
    int waitingProcessId = 0;
    std::string acquiredAt;
};

} // namespace models
} // namespace synccore
