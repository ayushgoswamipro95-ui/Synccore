#pragma once
#include <string>

namespace synccore {
namespace models {

struct User {
    int userId = 0;
    std::string username;
    std::string email;
    std::string passwordHash;
    std::string fullName;
    std::string role; // USER, ADMIN, SIMULATED
    std::string createdAt;
};

struct Movie {
    int movieId = 0;
    std::string title;
    std::string description;
    int durationMinutes = 0;
    std::string genre;
    std::string rating;
    std::string posterUrl;
    std::string releaseDate;
};

struct Theatre {
    int theatreId = 0;
    std::string name;
    std::string city;
    std::string address;
    int totalScreens = 1;
};

struct Screen {
    int screenId = 0;
    int theatreId = 0;
    int screenNumber = 1;
    std::string screenName;
    int totalCapacity = 50;
};

} // namespace models
} // namespace synccore
