#pragma once
#include <string>

namespace synccore {
namespace models {

struct ShowSeat {
    int showSeatId = 0;
    int showId = 0;
    int seatId = 0;
    std::string seatLabel;
    std::string seatType;
    double price = 0.0;
    std::string status = "AVAILABLE"; // AVAILABLE, LOCKED, BOOKED
    int version = 1;
};

} // namespace models
} // namespace synccore
