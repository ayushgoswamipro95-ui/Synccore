#pragma once
#include <string>

namespace synccore {
namespace models {

struct Seat {
    int seatId = 0;
    int screenId = 0;
    std::string rowName;
    int seatNumber = 0;
    std::string seatLabel; // e.g. G10
    std::string seatType;  // STANDARD, PREMIUM, VIP
};

struct ShowSeat {
    int showSeatId = 0;
    int showId = 0;
    int seatId = 0;
    std::string seatLabel;
    std::string seatType;
    double price = 0.0;
    std::string status; // AVAILABLE, LOCKED, BOOKED
    int version = 1;
};

struct Show {
    int showId = 0;
    int movieId = 0;
    int screenId = 0;
    std::string movieTitle;
    std::string screenName;
    std::string showTime;
    double basePrice = 250.0;
    int totalSeats = 24;
    int availableSeats = 24;
    std::string status;
};

} // namespace models
} // namespace synccore
