#pragma once
#include <string>
#include <vector>

namespace synccore {
namespace models {

struct BookingSeat {
    int bookingSeatId = 0;
    int bookingId = 0;
    int showSeatId = 0;
    std::string seatLabel;
    double seatPrice = 0.0;
};

struct Transaction {
    int transactionId = 0;
    std::string transactionReference;
    int bookingId = 0;
    double amount = 0.0;
    std::string paymentMethod; // CARD, UPI, RAZORPAY, SIMULATED_GATEWAY
    std::string paymentStatus; // CREATED, PENDING, SUCCESS, FAILED, REFUNDED
    std::string gatewayName;
    std::string gatewayOrderId;
    std::string gatewayPaymentId;
    std::string gatewaySignature;
    std::string gatewayResponseCode;
    std::string createdAt;
};

struct Booking {
    int bookingId = 0;
    std::string bookingReference;
    int userId = 0;
    int showId = 0;
    std::string customerName;
    std::string customerEmail;
    std::string movieTitle;
    std::string posterUrl;
    std::string theatreName;
    std::string screenName;
    std::string movieDate;
    std::string movieTime;
    std::string showTime;
    std::string seatsString;
    int totalSeats = 0;
    double totalAmount = 0.0;
    std::string bookingStatus; // PENDING, CONFIRMED, CANCELLED, FAILED
    std::string paymentStatus; // PENDING, SUCCESS, FAILED
    std::vector<BookingSeat> seats;
    std::string transactionReference;
    std::string createdAt;
};

} // namespace models
} // namespace synccore
