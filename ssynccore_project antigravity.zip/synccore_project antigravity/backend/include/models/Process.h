#pragma once
#include <string>
#include <vector>

namespace synccore {
namespace models {

enum class ProcessState {
    READY,
    RUNNING,
    WAITING,
    TERMINATED
};

inline std::string processStateToString(ProcessState state) {
    switch (state) {
        case ProcessState::READY: return "READY";
        case ProcessState::RUNNING: return "RUNNING";
        case ProcessState::WAITING: return "WAITING";
        case ProcessState::TERMINATED: return "TERMINATED";
        default: return "UNKNOWN";
    }
}

struct Process {
    int processId = 0;
    std::string processName; // e.g. "P1"
    std::string simulationRunId;
    int arrivalTime = 0;
    int burstTime = 10;
    int remainingTime = 10;
    int priority = 1;
    ProcessState state = ProcessState::READY;
    std::string requestedSeatLabel; // e.g. "G10"
    int targetShowId = 101;
    int startTime = -1;
    int completionTime = 0;
    int waitingTime = 0;
    int turnaroundTime = 0;
    std::string bookingStatus = "PENDING"; // PENDING, COMMITTED, ROLLED_BACK
    std::string waitReason;
};

} // namespace models
} // namespace synccore
