#pragma once
#include <vector>
#include <map>
#include <set>
#include <string>

namespace synccore {
namespace deadlock {

struct DeadlockInfo {
    bool hasDeadlock = false;
    std::vector<int> cycleProcessIds;
    std::vector<std::string> cycleResourceIds;
    std::string description;
};

class DeadlockDetector {
public:
    void addEdge(int waitingProcessId, int holdingProcessId);
    void removeEdge(int waitingProcessId, int holdingProcessId);
    void clear();

    DeadlockInfo detectDeadlock();

private:
    bool dfs(int current, std::map<int, bool>& visited, std::map<int, bool>& inStack, 
             std::vector<int>& path, std::vector<int>& cycle);
    std::map<int, std::set<int>> waitGraph_; // waitingProcess -> set of holdingProcesses
};

} // namespace deadlock
} // namespace synccore
