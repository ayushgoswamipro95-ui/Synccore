#pragma once
#include <string>
#include <vector>
#include <memory>
#include "DeadlockDetector.h"

namespace synccore {
namespace deadlock {

struct DeadlockSimulationState {
    bool isDeadlocked;
    std::string process1Holding;
    std::string process1Requesting;
    std::string process2Holding;
    std::string process2Requesting;
    std::vector<std::string> logEvents;
    std::string statusMessage;
};

class DeadlockSimulator {
public:
    DeadlockSimulator();

    DeadlockSimulationState triggerDeadlockScenario(const std::string& resA = "G10", const std::string& resB = "G11");
    DeadlockSimulationState recoverFromDeadlock(int victimProcessId = 1);
    void reset();

private:
    std::unique_ptr<DeadlockDetector> detector_;
    DeadlockSimulationState currentState_;
};

} // namespace deadlock
} // namespace synccore
