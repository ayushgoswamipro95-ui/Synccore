#pragma once
#include <string>
#include <memory>
#include <vector>
#include <map>
#include "../config/Config.h"

namespace synccore {
namespace database {

struct QueryResultRow {
    std::map<std::string, std::string> columns;
    std::string get(const std::string& col, const std::string& defaultVal = "") const {
        auto it = columns.find(col);
        return it != columns.end() ? it->second : defaultVal;
    }
};

class DatabaseConnection {
public:
    DatabaseConnection(const config::DatabaseConfig& cfg);
    ~DatabaseConnection();

    bool connect();
    void disconnect();
    bool isConnected() const;

    bool execute(const std::string& sql);
    std::vector<QueryResultRow> query(const std::string& sql);

    // Transaction controls
    bool beginTransaction();
    bool commit();
    bool rollback();

    std::string getLastError() const;

private:
    config::DatabaseConfig config_;
    bool connected_;
    bool inTransaction_;
    std::string lastError_;
};

} // namespace database
} // namespace synccore
