#pragma once
#include "DatabaseConnection.h"
#include <memory>
#include <functional>

namespace synccore {
namespace database {

class TransactionManager {
public:
    explicit TransactionManager(std::shared_ptr<DatabaseConnection> conn);

    bool beginTransaction();
    bool commit();
    bool rollback();
    bool isActive() const;

    // RAII Transaction Execution
    bool executeInTransaction(const std::function<bool()>& action);

private:
    std::shared_ptr<DatabaseConnection> connection_;
    bool inTransaction_;
};

} // namespace database
} // namespace synccore
