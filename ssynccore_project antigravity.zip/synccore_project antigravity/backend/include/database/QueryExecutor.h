#pragma once
#include "DatabaseConnection.h"
#include <string>
#include <vector>
#include <memory>

namespace synccore {
namespace database {

class QueryExecutor {
public:
    explicit QueryExecutor(std::shared_ptr<DatabaseConnection> conn);

    bool executeUpdate(const std::string& sql);
    std::vector<QueryResultRow> executeQuery(const std::string& sql);
    int getLastInsertId();

private:
    std::shared_ptr<DatabaseConnection> connection_;
};

} // namespace database
} // namespace synccore
