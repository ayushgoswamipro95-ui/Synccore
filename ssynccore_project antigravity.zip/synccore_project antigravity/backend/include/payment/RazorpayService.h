#pragma once
#include <string>
#include <vector>
#include <memory>
#include "../config/Config.h"

namespace synccore {
namespace payment {

struct RazorpayOrderResult {
    bool success = false;
    std::string orderId;
    int amountPaise = 0;
    std::string currency = "INR";
    std::string keyId;
    std::string errorMessage;
};

class RazorpayService {
public:
    RazorpayService();
    explicit RazorpayService(const config::RazorpayConfig& cfg);

    RazorpayOrderResult createOrder(double amountInRupees, const std::string& receipt);
    bool verifySignature(const std::string& orderId, const std::string& paymentId, const std::string& signature);
    bool verifyWebhookSignature(const std::string& rawPayload, const std::string& signature);

    std::string getKeyId() const { return config_.keyId; }

private:
    config::RazorpayConfig config_;
};

} // namespace payment
} // namespace synccore
