#pragma once
#include "SimulationResult.h"
#include <vector>

namespace synccore {
namespace simulation {

class PerformanceAnalyzer {
public:
    static void computeMetrics(SimulationResult& result);
    static std::string compareAlgorithms(const std::vector<SimulationResult>& results);
};

} // namespace simulation
} // namespace synccore
