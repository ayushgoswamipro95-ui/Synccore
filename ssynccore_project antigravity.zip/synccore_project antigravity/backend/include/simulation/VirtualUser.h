#pragma once
#include "SimulationResult.h"

namespace synccore {
namespace simulation {

// VirtualUser declared in SimulationResult.h

} // namespace simulation
} // namespace synccore
