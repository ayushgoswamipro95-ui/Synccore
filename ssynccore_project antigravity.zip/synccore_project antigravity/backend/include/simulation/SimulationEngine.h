#pragma once
#include "SimulationResult.h"
#include "../os/ReadyQueue.h"
#include "../os/SchedulerManager.h"
#include "../concurrency/LockManager.h"
#include <memory>
#include <functional>

namespace synccore {
namespace simulation {

class SimulationEngine {
public:
    SimulationEngine();

    SimulationResult runSimulation(const SimulationConfig& config);
    bool isRunning() const { return isRunning_; }
    void stop();

    void setProgressCallback(std::function<void(const std::string&)> cb) {
        progressCallback_ = cb;
    }

private:
    bool isRunning_;
    std::function<void(const std::string&)> progressCallback_;
};

} // namespace simulation
} // namespace synccore
