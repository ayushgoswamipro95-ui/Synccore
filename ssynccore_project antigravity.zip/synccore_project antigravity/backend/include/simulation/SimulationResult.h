#pragma once
#include <string>
#include <vector>
#include "../models/Process.h"

namespace synccore {
namespace simulation {

struct VirtualUser {
    int id;
    std::string name;
    int targetShowId;
    std::string preferredSeat;
    int priority;
    int latencyMs;
};

struct SimulationConfig {
    std::string runId;
    std::string algorithm; // FCFS, SJF, PRIORITY
    int processCount = 5;
    std::string contentionLevel = "HIGH"; // LOW, MEDIUM, HIGH
    bool enableSynchronization = true;
};

struct GanttChartEntry {
    int processId;
    std::string processName;
    int startTime;
    int endTime;
};

struct SimulationResult {
    std::string runId;
    std::string algorithm;
    int totalProcesses = 0;
    int successfulBookings = 0;
    int failedBookings = 0;
    int rollbacks = 0;
    double avgWaitingTime = 0.0;
    double avgTurnaroundTime = 0.0;
    double cpuUtilization = 0.0;
    double throughput = 0.0;
    std::vector<models::Process> processList;
    std::vector<GanttChartEntry> ganttChart;
    std::vector<std::string> eventLogs;
};

} // namespace simulation
} // namespace synccore
