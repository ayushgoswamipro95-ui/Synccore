#include <iostream>
#include <cassert>
#include "../../include/booking/BookingService.h"

using namespace synccore;

int main() {
    std::cout << "[TEST] Running Booking Unit Tests...\n";
    config::DatabaseConfig dbCfg;
    auto conn = std::make_shared<database::DatabaseConnection>(dbCfg);
    conn->connect();

    booking::BookingService svc(conn);
    booking::BookingRequest req;
    req.userId = 1;
    req.showId = 101;
    req.showSeatIds = {1, 2};

    auto res = svc.createBooking(req);
    assert(res.success == true);
    std::cout << "  ✓ Booking Creation Verified\n";

    std::cout << "[TEST] Booking Tests Passed Successfully!\n";
    return 0;
}
