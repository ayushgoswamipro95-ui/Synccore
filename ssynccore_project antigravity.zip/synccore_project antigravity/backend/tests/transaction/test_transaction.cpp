#include <iostream>
#include <cassert>
#include "../../include/database/TransactionManager.h"

using namespace synccore;

int main() {
    std::cout << "[TEST] Running Transaction Manager Unit Tests...\n";
    config::DatabaseConfig dbCfg;
    auto conn = std::make_shared<database::DatabaseConnection>(dbCfg);
    conn->connect();

    database::TransactionManager tm(conn);
    assert(tm.beginTransaction() == true);
    assert(tm.isActive() == true);
    assert(tm.commit() == true);
    assert(tm.isActive() == false);
    std::cout << "  ✓ Transaction Commit Lifecycle Verified\n";

    assert(tm.beginTransaction() == true);
    assert(tm.rollback() == true);
    assert(tm.isActive() == false);
    std::cout << "  ✓ Transaction Rollback Lifecycle Verified\n";

    std::cout << "[TEST] Transaction Tests Passed Successfully!\n";
    return 0;
}
