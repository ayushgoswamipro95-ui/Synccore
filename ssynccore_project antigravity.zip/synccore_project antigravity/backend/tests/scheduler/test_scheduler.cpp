#include <iostream>
#include <cassert>
#include "../../include/os/SchedulerManager.h"

using namespace synccore::os;

int main() {
    std::cout << "[TEST] Running Scheduler Unit Tests...\n";
    std::vector<Process> procs;
    
    Process p1; p1.processId = 1; p1.arrivalTime = 2; p1.burstTime = 10;
    Process p2; p2.processId = 2; p2.arrivalTime = 0; p2.burstTime = 4;
    procs.push_back(p1);
    procs.push_back(p2);

    FCFSScheduler fcfs;
    auto resFcfs = fcfs.schedule(procs);
    assert(resFcfs[0].processId == 2); // p2 arrived first
    std::cout << "  ✓ FCFS Ordering Verified\n";

    SJFScheduler sjf;
    auto resSjf = sjf.schedule(procs);
    assert(resSjf[0].processId == 2); // p2 has shorter burst time
    std::cout << "  ✓ SJF Ordering Verified\n";

    std::cout << "[TEST] Scheduler Tests Passed Successfully!\n";
    return 0;
}
