#include <iostream>
#include <cassert>
#include "../../include/deadlock/DeadlockSimulator.h"

using namespace synccore::deadlock;

int main() {
    std::cout << "[TEST] Running Deadlock Unit Tests...\n";
    DeadlockSimulator sim;
    auto state = sim.triggerDeadlockScenario("G10", "G11");
    assert(state.isDeadlocked == true);
    std::cout << "  ✓ Deadlock Cycle Detection Verified\n";

    auto recState = sim.recoverFromDeadlock(1);
    assert(recState.isDeadlocked == false);
    std::cout << "  ✓ Deadlock Recovery & Graph Reset Verified\n";

    std::cout << "[TEST] Deadlock Tests Passed Successfully!\n";
    return 0;
}
