#include <iostream>
#include <cassert>
#include "../../include/concurrency/MutexManager.h"
#include "../../include/concurrency/RaceConditionSimulator.h"

using namespace synccore::concurrency;

int main() {
    std::cout << "[TEST] Running Concurrency Unit Tests...\n";
    auto& mm = MutexManager::getInstance();
    mm.reset();

    assert(mm.lock("G10", 1) == true);
    assert(mm.lock("G10", 2) == false); // Process 2 blocked
    assert(mm.unlock("G10", 1) == true);
    assert(mm.lock("G10", 2) == true); // Process 2 now acquires

    std::cout << "  ✓ Mutex Lock/Unlock and Contention Verified\n";

    RaceConditionSimulator raceSim;
    auto raceRes = raceSim.runDemo(true, "G10");
    assert(raceRes.process1Success == true);
    assert(raceRes.process2Success == false);
    std::cout << "  ✓ Synchronized Race Condition Avoidance Verified\n";

    std::cout << "[TEST] Concurrency Tests Passed Successfully!\n";
    return 0;
}
