#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <sstream>
#include <cstdlib>
#include <algorithm>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#endif

#include "../include/config/Config.h"
#include "../include/config/Constants.h"
#include "../include/crypto/Sha256.h"
#include "../include/auth/AuthService.h"
#include "../include/payment/RazorpayService.h"
#include "../include/database/DatabaseConnection.h"
#include "../include/database/TransactionManager.h"
#include "../include/booking/BookingService.h"
#include "../include/booking/SeatService.h"
#include "../include/os/ProcessManager.h"
#include "../include/os/SchedulerManager.h"
#include "../include/concurrency/MutexManager.h"
#include "../include/concurrency/RaceConditionSimulator.h"
#include "../include/deadlock/DeadlockSimulator.h"
#include "../include/simulation/SimulationEngine.h"

using namespace synccore;

void printBanner() {
    std::cout << "===============================================================\n";
    std::cout << "  SyncCore — Movie Booking & OS/DBMS Concurrency Simulator\n";
    std::cout << "  Version: " << config::Constants::APP_VERSION << "\n";
    std::cout << "  Database: MySQL 8.4 InnoDB ACID Engine (synccore_db)\n";
    std::cout << "  Developed for College PBL (Operating Systems + DBMS)\n";
    std::cout << "===============================================================\n\n";
}

void runCliDemonstration() {
    std::cout << "[*] Executing Core OS & Concurrency Diagnostics...\n\n";

    // 1. Process and Scheduler Verification
    std::cout << "[1] Testing OS CPU Schedulers (FCFS vs SJF vs Priority):\n";
    simulation::SimulationConfig cfg;
    cfg.runId = "RUN_CLI_ACTIVE";
    cfg.processCount = 4;
    cfg.contentionLevel = "HIGH";
    cfg.enableSynchronization = true;

    simulation::SimulationEngine engine;
    
    cfg.algorithm = "FCFS";
    auto resFcfs = engine.runSimulation(cfg);
    std::cout << "    - FCFS Avg Waiting Time: " << resFcfs.avgWaitingTime 
              << " ms | Committed: " << resFcfs.successfulBookings 
              << " | Rollbacks: " << resFcfs.rollbacks << "\n";

    cfg.algorithm = "SJF";
    auto resSjf = engine.runSimulation(cfg);
    std::cout << "    - SJF  Avg Waiting Time: " << resSjf.avgWaitingTime 
              << " ms | Committed: " << resSjf.successfulBookings 
              << " | Rollbacks: " << resSjf.rollbacks << "\n";

    // 2. Race Condition Simulation Verification
    std::cout << "\n[2] Testing Race Condition Demonstration:\n";
    concurrency::RaceConditionSimulator raceSim;
    auto raceWithout = raceSim.runDemo(false, "G10");
    std::cout << "    - Without Sync: " << raceWithout.outcomeDescription << "\n";
    auto raceWith = raceSim.runDemo(true, "G10");
    std::cout << "    - With Sync:    " << raceWith.outcomeDescription << "\n";

    // 3. Deadlock Simulation Verification
    std::cout << "\n[3] Testing Deadlock Detection (Wait-For-Graph DFS):\n";
    deadlock::DeadlockSimulator deadlockSim;
    auto dlState = deadlockSim.triggerDeadlockScenario("G10", "G11");
    std::cout << "    - Deadlock status: " << (dlState.isDeadlocked ? "DEADLOCK DETECTED" : "NORMAL") << "\n";
    std::cout << "    - Details: " << dlState.statusMessage << "\n";
    auto recoveryState = deadlockSim.recoverFromDeadlock(1);
    std::cout << "    - After Recovery: " << recoveryState.statusMessage << "\n\n";

    std::cout << "[✓] All OS Scheduling and Concurrency models initialized successfully!\n";
}

#ifdef _WIN32
void startHttpServer(int port, std::shared_ptr<database::DatabaseConnection> dbConn) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed\n";
        return;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Socket creation failed\n";
        WSACleanup();
        return;
    }

    // Set SO_REUSEADDR so port is immediately reusable
    int opt = 1;
    setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(port);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Socket bind failed on port " << port << "\n";
        closesocket(serverSocket);
        WSACleanup();
        return;
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        std::cerr << "Listen failed\n";
        closesocket(serverSocket);
        WSACleanup();
        return;
    }

    std::cout << "\n===============================================================\n";
    std::cout << "[HTTP SERVER] SyncCore Live REST Backend Running on http://localhost:" << port << "\n";
    std::cout << "[HTTP SERVER] Integrated with MySQL 8.4 Server (synccore_db)\n";
    std::cout << "[HTTP SERVER] Razorpay Integration Active (Key: " 
              << config::Config::getInstance().getRazorpayConfig().keyId << ")\n";
    std::cout << "[HTTP SERVER] Ready to serve frontend API requests!\n";
    std::cout << "===============================================================\n\n";

    auth::AuthService authService(dbConn);
    payment::RazorpayService razorpayService;
    booking::SeatService seatService(dbConn);
    booking::BookingService bookingService(dbConn);

    // Helper to extract JSON fields
    auto extractJson = [](const std::string& json, const std::string& field, const std::string& defVal = "") -> std::string {
        std::string key = "\"" + field + "\"";
        size_t pos = json.find(key);
        if (pos == std::string::npos) return defVal;
        pos = json.find(':', pos);
        if (pos == std::string::npos) return defVal;
        pos = json.find_first_not_of(" \t\r\n", pos + 1);
        if (pos == std::string::npos) return defVal;
        if (json[pos] == '\"') {
            size_t end = json.find('\"', pos + 1);
            return (end != std::string::npos) ? json.substr(pos + 1, end - pos - 1) : defVal;
        } else {
            size_t end = json.find_first_of(",}\r\n", pos);
            return (end != std::string::npos) ? json.substr(pos, end - pos) : defVal;
        }
    };

    // Helper to extract Bearer token from header
    auto extractToken = [](const std::string& req) -> std::string {
        size_t pos = req.find("Authorization: Bearer ");
        if (pos == std::string::npos) {
            pos = req.find("authorization: bearer ");
        }
        if (pos == std::string::npos) {
            pos = req.find("token=");
            if (pos != std::string::npos) {
                size_t end = req.find_first_of(" &\r\n", pos + 6);
                return req.substr(pos + 6, (end != std::string::npos ? end - (pos + 6) : std::string::npos));
            }
            return "";
        }
        pos += 22;
        size_t end = req.find_first_of("\r\n", pos);
        std::string tok = (end != std::string::npos) ? req.substr(pos, end - pos) : req.substr(pos);
        // Trim whitespace
        size_t first = tok.find_first_not_of(" \t");
        size_t last = tok.find_last_not_of(" \t");
        return (first != std::string::npos && last != std::string::npos) ? tok.substr(first, last - first + 1) : tok;
    };

    // Helper to extract query parameters
    auto extractQueryParam = [](const std::string& req, const std::string& param, const std::string& defVal = "") -> std::string {
        std::string key = param + "=";
        size_t pos = req.find(key);
        if (pos == std::string::npos) return defVal;
        pos += key.length();
        size_t end = req.find_first_of(" &\r\nHTTP", pos);
        return (end != std::string::npos) ? req.substr(pos, end - pos) : req.substr(pos);
    };

    // Handle requests
    while (true) {
        SOCKET clientSocket = accept(serverSocket, NULL, NULL);
        if (clientSocket == INVALID_SOCKET) break;

        char buffer[8192] = {0};
        recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        std::string request(buffer);

        std::string responseBody;
        std::string contentType = "application/json";
        int statusCode = 200;
        std::string statusText = "OK";

        size_t clPos = request.find("Content-Length:");
        if (clPos == std::string::npos) clPos = request.find("content-length:");
        int cl = 0;
        if (clPos != std::string::npos) {
            cl = std::atoi(request.c_str() + clPos + 15);
        }

        size_t bodyPos = request.find("\r\n\r\n");
        std::string body = "";
        if (bodyPos != std::string::npos) {
            body = request.substr(bodyPos + 4);
        } else {
            bodyPos = request.find("\n\n");
            if (bodyPos != std::string::npos) {
                body = request.substr(bodyPos + 2);
            }
        }

        while (cl > 0 && body.length() < static_cast<size_t>(cl)) {
            char chunk[1024] = {0};
            int n = recv(clientSocket, chunk, sizeof(chunk) - 1, 0);
            if (n <= 0) break;
            body.append(chunk, n);
            request.append(chunk, n);
        }
        if (body.empty()) body = request;

        // Parse token and current user session
        std::string token = extractToken(request);
        auth::UserSession currentUser;
        bool hasUser = authService.getSession(token, currentUser);

        // CORS preflight
        if (request.find("OPTIONS") == 0) {
            responseBody = "{\"status\":\"OK\"}";
        } 
        // 1. Health and Status
        else if (request.find("GET /api/status") != std::string::npos) {
            bool dbOk = dbConn && dbConn->isConnected();
            responseBody = "{\"status\":\"ONLINE\",\"version\":\"" + config::Constants::APP_VERSION + 
                           "\",\"database\":\"" + (dbOk ? "CONNECTED" : "OFFLINE") + 
                           "\",\"engine\":\"MySQL 8.4 InnoDB\",\"schema\":\"synccore_db\"" +
                           ",\"razorpayKeyId\":\"" + razorpayService.getKeyId() + "\"}";
        }
        // 2. Authentication: Signup
        else if (request.find("POST /api/auth/signup") != std::string::npos) {
            std::string name = extractJson(body, "fullName");
            if (name.empty()) name = extractJson(body, "name");
            std::string email = extractJson(body, "email");
            std::string pass = extractJson(body, "password");
            std::string phone = extractJson(body, "phone");

            auto res = authService.signup(name, email, pass, phone);
            if (res.success) {
                responseBody = "{\"success\":true,\"token\":\"" + res.token + 
                               "\",\"user\":{\"id\":" + std::to_string(res.user.userId) + 
                               ",\"name\":\"" + res.user.fullName + 
                               "\",\"email\":\"" + res.user.email + 
                               "\",\"role\":\"" + res.user.role + 
                               "\",\"phone\":\"" + res.user.phone + "\"},\"message\":\"" + res.message + "\"}";
            } else {
                statusCode = 400;
                statusText = "Bad Request";
                responseBody = "{\"success\":false,\"message\":\"" + res.message + "\"}";
            }
        }
        // 3. Authentication: Login
        else if (request.find("POST /api/auth/login") != std::string::npos) {
            std::string email = extractJson(body, "email");
            if (email.empty()) email = extractJson(body, "username");
            std::string pass = extractJson(body, "password");

            auto res = authService.login(email, pass);
            if (res.success) {
                responseBody = "{\"success\":true,\"token\":\"" + res.token + 
                               "\",\"user\":{\"id\":" + std::to_string(res.user.userId) + 
                               ",\"name\":\"" + res.user.fullName + 
                               "\",\"email\":\"" + res.user.email + 
                               "\",\"role\":\"" + res.user.role + 
                               "\",\"phone\":\"" + res.user.phone + "\"},\"message\":\"" + res.message + "\"}";
            } else {
                statusCode = 401;
                statusText = "Unauthorized";
                responseBody = "{\"success\":false,\"message\":\"" + res.message + "\"}";
            }
        }
        // 4. Authentication: Logout
        else if (request.find("POST /api/auth/logout") != std::string::npos) {
            authService.logout(token);
            responseBody = "{\"success\":true,\"message\":\"Logged out successfully\"}";
        }
        // 5. Authentication: Current User
        else if (request.find("GET /api/auth/me") != std::string::npos) {
            if (hasUser) {
                responseBody = "{\"authenticated\":true,\"user\":{\"id\":" + std::to_string(currentUser.userId) + 
                               ",\"name\":\"" + currentUser.fullName + 
                               "\",\"email\":\"" + currentUser.email + 
                               "\",\"role\":\"" + currentUser.role + 
                               "\",\"phone\":\"" + currentUser.phone + "\"}}";
            } else {
                statusCode = 401;
                statusText = "Unauthorized";
                responseBody = "{\"authenticated\":false,\"message\":\"Please log in.\"}";
            }
        }
        // 6. Movies Catalog
        else if (request.find("GET /api/movies") != std::string::npos && request.find("/api/movies/dates") == std::string::npos) {
            std::ostringstream json;
            json << "[";
            if (dbConn && dbConn->isConnected()) {
                auto rows = dbConn->query("SELECT movie_id, title, duration_minutes, genre, rating, poster_url, description, certificate, language FROM movies ORDER BY movie_id ASC;");
                for (size_t i = 0; i < rows.size(); ++i) {
                    if (i > 0) json << ",";
                    std::string pUrl = rows[i].get("poster_url");
                    if (pUrl.empty()) pUrl = "assets/images/inception.jpg";
                    json << "{\"id\":" << rows[i].get("movie_id", "0")
                         << ",\"title\":\"" << rows[i].get("title") << "\""
                         << ",\"duration\":\"" << rows[i].get("duration_minutes", "148") << " mins\""
                         << ",\"genre\":\"" << rows[i].get("genre", "Action") << "\""
                         << ",\"rating\":\"" << rows[i].get("rating", "8.5") << "\""
                         << ",\"poster\":\"" << pUrl << "\""
                         << ",\"certificate\":\"" << rows[i].get("certificate", "U/A 16+") << "\""
                         << ",\"languages\":\"" << rows[i].get("language", "English, Hindi") << "\""
                         << ",\"description\":\"" << rows[i].get("description", "SyncCore Cinema Premiere") << "\"}";
                }
            }
            json << "]";
            responseBody = json.str();
        }
        // 7. Available Show Dates for Movie
        else if (request.find("GET /api/movies/dates") != std::string::npos || request.find("GET /api/shows/dates") != std::string::npos) {
            std::string mIdStr = extractQueryParam(request, "movieId", "1");
            int movieId = std::atoi(mIdStr.c_str());

            std::ostringstream json;
            json << "[";
            if (dbConn && dbConn->isConnected()) {
                std::string sql = "SELECT DISTINCT DATE(show_time) as sdate FROM shows WHERE movie_id = " 
                                  + std::to_string(movieId) + " ORDER BY sdate ASC;";
                auto rows = dbConn->query(sql);
                for (size_t i = 0; i < rows.size(); ++i) {
                    if (i > 0) json << ",";
                    json << "\"" << rows[i].get("sdate") << "\"";
                }
            }
            json << "]";
            responseBody = json.str();
        }
        // 8. Filtered Shows by Movie and Date
        else if (request.find("GET /api/shows") != std::string::npos) {
            std::string mIdStr = extractQueryParam(request, "movieId", "1");
            std::string dateStr = extractQueryParam(request, "date", "");

            std::string dateFilter = dateStr.empty() ? "" : (" AND DATE(s.show_time) = '" + dateStr + "'");
            std::string sql = 
                "SELECT s.show_id, s.movie_id, s.screen_id, s.show_time, s.base_price, s.available_seats, s.total_seats, "
                "sc.screen_name, COALESCE(sc.screen_type, '2D') as screen_type, t.name as theatre_name, t.city "
                "FROM shows s "
                "JOIN screens sc ON s.screen_id = sc.screen_id "
                "JOIN theatres t ON sc.theatre_id = t.theatre_id "
                "WHERE s.movie_id = " + mIdStr + dateFilter + " ORDER BY s.show_time ASC;";

            std::ostringstream json;
            json << "[";
            if (dbConn && dbConn->isConnected()) {
                auto rows = dbConn->query(sql);
                for (size_t i = 0; i < rows.size(); ++i) {
                    if (i > 0) json << ",";
                    std::string fullTime = rows[i].get("show_time");
                    std::string sDate = fullTime.substr(0, 10);
                    std::string sTime = (fullTime.length() >= 16) ? fullTime.substr(11, 5) : "18:00";

                    json << "{\"showId\":" << rows[i].get("show_id")
                         << ",\"movieId\":" << rows[i].get("movie_id")
                         << ",\"theatreName\":\"" << rows[i].get("theatre_name") << "\""
                         << ",\"theatreCity\":\"" << rows[i].get("city") << "\""
                         << ",\"screenId\":" << rows[i].get("screen_id")
                         << ",\"screenName\":\"" << rows[i].get("screen_name") << "\""
                         << ",\"screenType\":\"" << rows[i].get("screen_type") << "\""
                         << ",\"showDate\":\"" << sDate << "\""
                         << ",\"showTime\":\"" << sTime << "\""
                         << ",\"basePrice\":" << rows[i].get("base_price", "350.0")
                         << ",\"availableSeats\":" << rows[i].get("available_seats", "24")
                         << ",\"totalSeats\":" << rows[i].get("total_seats", "24") << "}";
                }
            }
            json << "]";
            responseBody = json.str();
        }
        // 9. Screens List
        else if (request.find("GET /api/screens") != std::string::npos) {
            std::string tIdStr = extractQueryParam(request, "theatreId", "0");
            std::string filter = (tIdStr != "0") ? ("WHERE s.theatre_id = " + tIdStr) : "";
            std::string sql = "SELECT s.screen_id, s.theatre_id, s.screen_number, s.screen_name, COALESCE(s.screen_type, '2D') as screen_type, "
                              "s.total_capacity, t.name as theatre_name FROM screens s JOIN theatres t ON s.theatre_id = t.theatre_id " + filter + " ORDER BY s.screen_id ASC;";

            std::ostringstream json;
            json << "[";
            if (dbConn && dbConn->isConnected()) {
                auto rows = dbConn->query(sql);
                for (size_t i = 0; i < rows.size(); ++i) {
                    if (i > 0) json << ",";
                    json << "{\"screenId\":" << rows[i].get("screen_id")
                         << ",\"theatreId\":" << rows[i].get("theatre_id")
                         << ",\"theatreName\":\"" << rows[i].get("theatre_name") << "\""
                         << ",\"screenNumber\":" << rows[i].get("screen_number")
                         << ",\"screenName\":\"" << rows[i].get("screen_name") << "\""
                         << ",\"screenType\":\"" << rows[i].get("screen_type") << "\""
                         << ",\"capacity\":" << rows[i].get("total_capacity", "24") << "}";
                }
            }
            json << "]";
            responseBody = json.str();
        }
        // 10. Theatres List
        else if (request.find("GET /api/theatres") != std::string::npos || request.find("GET /api/admin/theatres") != std::string::npos) {
            std::ostringstream json;
            json << "[";
            if (dbConn && dbConn->isConnected()) {
                auto rows = dbConn->query("SELECT theatre_id, name, city, address FROM theatres ORDER BY theatre_id ASC;");
                for (size_t i = 0; i < rows.size(); ++i) {
                    if (i > 0) json << ",";
                    json << "{\"theatreId\":" << rows[i].get("theatre_id")
                         << ",\"name\":\"" << rows[i].get("name") << "\""
                         << ",\"city\":\"" << rows[i].get("city") << "\""
                         << ",\"address\":\"" << rows[i].get("address") << "\"}";
                }
            }
            json << "]";
            responseBody = json.str();
        }
        // 11. Seat Layout for Show
        else if (request.find("GET /api/seats") != std::string::npos) {
            std::string sIdStr = extractQueryParam(request, "showId", "101");
            int showId = std::atoi(sIdStr.c_str());
            auto seats = seatService.getSeatsForShow(showId);

            std::ostringstream json;
            json << "[";
            for (size_t i = 0; i < seats.size(); ++i) {
                if (i > 0) json << ",";
                json << "{\"showSeatId\":" << seats[i].showSeatId
                     << ",\"seatId\":" << seats[i].seatId
                     << ",\"label\":\"" << seats[i].seatLabel << "\""
                     << ",\"type\":\"" << seats[i].seatType << "\""
                     << ",\"price\":" << seats[i].price
                     << ",\"status\":\"" << seats[i].status << "\"}";
            }
            json << "]";
            responseBody = json.str();
        }
        // 12. Razorpay Payment: Create Order
        else if (request.find("POST /api/payment/create-order") != std::string::npos) {
            int uid = hasUser ? currentUser.userId : std::atoi(extractJson(body, "userId", "1").c_str());
            if (uid <= 0) uid = 1;

            booking::BookingRequest req;
            req.userId = uid;
            req.showId = std::atoi(extractJson(body, "showId", "101").c_str());
            req.customerName = hasUser ? currentUser.fullName : extractJson(body, "customerName", "Guest Customer");
            req.customerEmail = hasUser ? currentUser.email : extractJson(body, "customerEmail", "guest@synccore.com");
            req.movieTitle = extractJson(body, "movieTitle", "SyncCore Cinema");
            req.movieDate = extractJson(body, "movieDate", "2026-10-15");
            req.movieTime = extractJson(body, "movieTime", "18:00");

            // Extract seat IDs or seat labels from body
            std::vector<int> targetSeatIds;
            if (dbConn && dbConn->isConnected()) {
                std::string rows[] = {"A", "B", "C", "D", "E", "F", "G"};
                for (const auto& r : rows) {
                    for (int i = 1; i <= 15; ++i) {
                        std::string label = (r == "G" && i < 10) ? ("G" + std::to_string(9 + i)) : (r + std::to_string(i));
                        if (body.find("\"" + label + "\"") != std::string::npos || body.find(label) != std::string::npos) {
                            auto qRows = dbConn->query("SELECT ss.show_seat_id FROM show_seats ss JOIN seats s ON ss.seat_id = s.seat_id WHERE ss.show_id = " + std::to_string(req.showId) + " AND s.seat_label = '" + label + "' LIMIT 1;");
                            if (!qRows.empty()) {
                                targetSeatIds.push_back(std::atoi(qRows[0].get("show_seat_id").c_str()));
                            }
                        }
                    }
                }
            }

            if (targetSeatIds.empty()) {
                targetSeatIds.push_back(1); // default fallback
            }
            req.showSeatIds = targetSeatIds;

            // Execute database seat reservation (pessimistic lock)
            auto res = bookingService.createPendingReservation(req);
            if (!res.success) {
                statusCode = 409;
                statusText = "Conflict";
                responseBody = "{\"success\":false,\"message\":\"" + res.message + "\"}";
            } else {
                // Create Razorpay Order
                auto orderRes = razorpayService.createOrder(res.amount, res.bookingReference);
                if (orderRes.success) {
                    // Update transactions table with Razorpay order ID
                    if (dbConn && dbConn->isConnected()) {
                        dbConn->execute("UPDATE transactions SET gateway_order_id = '" + orderRes.orderId + 
                                        "' WHERE booking_id = " + std::to_string(res.bookingId) + ";");
                    }

                    responseBody = "{\"success\":true,\"orderId\":\"" + orderRes.orderId + 
                                   "\",\"keyId\":\"" + orderRes.keyId + 
                                   "\",\"amount\":" + std::to_string(orderRes.amountPaise) + 
                                   ",\"currency\":\"" + orderRes.currency + 
                                   "\",\"bookingId\":" + std::to_string(res.bookingId) + 
                                   ",\"bookingReference\":\"" + res.bookingReference + 
                                   "\",\"totalAmount\":" + std::to_string(res.amount) + 
                                   ",\"movieTitle\":\"" + res.movieTitle + 
                                   "\",\"customerName\":\"" + res.customerName + 
                                   "\",\"customerEmail\":\"" + req.customerEmail + "\"}";
                } else {
                    bookingService.rollbackFailedPayment(res.bookingId, req.userId, "Razorpay order creation failed");
                    statusCode = 502;
                    statusText = "Bad Gateway";
                    responseBody = "{\"success\":false,\"message\":\"Payment gateway initialization failed. " + orderRes.errorMessage + "\"}";
                }
            }
        }
        // 13. Razorpay Payment: Verify Payment Signature
        else if (request.find("POST /api/payment/verify") != std::string::npos) {
            int bookingId = std::atoi(extractJson(body, "bookingId", "0").c_str());
            std::string orderId = extractJson(body, "razorpayOrderId");
            if (orderId.empty()) orderId = extractJson(body, "razorpay_order_id");
            std::string payId = extractJson(body, "razorpayPaymentId");
            if (payId.empty()) payId = extractJson(body, "razorpay_payment_id");
            std::string sig = extractJson(body, "razorpaySignature");
            if (sig.empty()) sig = extractJson(body, "razorpay_signature");

            int uid = hasUser ? currentUser.userId : std::atoi(extractJson(body, "userId", "1").c_str());

            bool validSig = razorpayService.verifySignature(orderId, payId, sig);
            if (validSig) {
                auto confirmRes = bookingService.confirmBookingPayment(bookingId, uid, orderId, payId, sig);
                if (confirmRes.success) {
                    responseBody = "{\"success\":true,\"bookingReference\":\"" + confirmRes.bookingReference + 
                                   "\",\"bookingId\":" + std::to_string(confirmRes.bookingId) + 
                                   ",\"totalAmount\":" + std::to_string(confirmRes.amount) + 
                                   ",\"customerName\":\"" + confirmRes.customerName + 
                                   "\",\"movieTitle\":\"" + confirmRes.movieTitle + 
                                   "\",\"movieDate\":\"" + confirmRes.movieDate + 
                                   "\",\"movieTime\":\"" + confirmRes.movieTime + 
                                   "\",\"transactionId\":\"" + payId + 
                                   "\",\"message\":\"Payment verified and booking confirmed!\"}";
                } else {
                    statusCode = 500;
                    responseBody = "{\"success\":false,\"message\":\"" + confirmRes.message + "\"}";
                }
            } else {
                bookingService.rollbackFailedPayment(bookingId, uid, "Invalid payment signature");
                statusCode = 400;
                statusText = "Payment Verification Failed";
                responseBody = "{\"success\":false,\"message\":\"Payment signature verification failed. Reservation aborted.\"}";
            }
        }
        // 14. Razorpay Webhook Endpoint
        else if (request.find("POST /api/payment/webhook") != std::string::npos) {
            std::string sig = extractJson(body, "signature");
            std::cout << "[Razorpay Webhook] Received webhook notification: " << body.substr(0, 100) << "...\n";
            responseBody = "{\"status\":\"ok\"}";
        }
        // 15. User Booking History (Filtered by Logged-In User)
        else if (request.find("GET /api/my-bookings") != std::string::npos) {
            if (!hasUser) {
                statusCode = 401;
                statusText = "Unauthorized";
                responseBody = "{\"error\":\"Please log in to view your bookings.\"}";
            } else {
                auto bookings = bookingService.getUserBookingsDetailed(currentUser.userId);
                std::ostringstream json;
                json << "[";
                for (size_t i = 0; i < bookings.size(); ++i) {
                    if (i > 0) json << ",";
                    json << "{\"bookingId\":" << bookings[i].bookingId
                         << ",\"bookingReference\":\"" << bookings[i].bookingReference << "\""
                         << ",\"movieTitle\":\"" << bookings[i].movieTitle << "\""
                         << ",\"posterUrl\":\"" << bookings[i].posterUrl << "\""
                         << ",\"theatreName\":\"" << bookings[i].theatreName << "\""
                         << ",\"screenName\":\"" << bookings[i].screenName << "\""
                         << ",\"movieDate\":\"" << bookings[i].movieDate << "\""
                         << ",\"movieTime\":\"" << bookings[i].movieTime << "\""
                         << ",\"seats\":\"" << bookings[i].seatsString << "\""
                         << ",\"totalSeats\":" << bookings[i].totalSeats
                         << ",\"totalAmount\":" << bookings[i].totalAmount
                         << ",\"bookingStatus\":\"" << bookings[i].bookingStatus << "\""
                         << ",\"paymentStatus\":\"" << bookings[i].paymentStatus << "\""
                         << ",\"createdAt\":\"" << bookings[i].createdAt << "\"}";
                }
                json << "]";
                responseBody = json.str();
            }
        }
        // 16. User Cancel Booking
        else if (request.find("POST /api/bookings/cancel") != std::string::npos) {
            if (!hasUser) {
                statusCode = 401;
                responseBody = "{\"success\":false,\"message\":\"Authentication required\"}";
            } else {
                int bId = std::atoi(extractJson(body, "bookingId", "0").c_str());
                std::string msg;
                bool ok = bookingService.cancelBookingByUser(bId, currentUser.userId, msg);
                responseBody = "{\"success\":" + std::string(ok ? "true" : "false") + ",\"message\":\"" + msg + "\"}";
            }
        }
        // 17. Ticket Generation / Details
        else if (request.find("GET /api/ticket") != std::string::npos || request.find("GET /api/bookings/ticket") != std::string::npos) {
            std::string bIdStr = extractQueryParam(request, "id", "0");
            int bId = std::atoi(bIdStr.c_str());
            int uid = hasUser ? currentUser.userId : 1;
            bool isAdmin = hasUser && (currentUser.role == "ADMIN");

            auto t = bookingService.getTicketDetails(bId, uid, isAdmin);
            if (t.bookingId > 0) {
                responseBody = "{\"bookingId\":" + std::to_string(t.bookingId) + 
                               ",\"bookingReference\":\"" + t.bookingReference + 
                               "\",\"customerName\":\"" + t.customerName + 
                               "\",\"customerEmail\":\"" + t.customerEmail + 
                               "\",\"movieTitle\":\"" + t.movieTitle + 
                               "\",\"posterUrl\":\"" + t.posterUrl + 
                               "\",\"theatreName\":\"" + t.theatreName + 
                               "\",\"screenName\":\"" + t.screenName + 
                               "\",\"showDate\":\"" + t.movieDate + 
                               "\",\"showTime\":\"" + t.movieTime + 
                               "\",\"seats\":\"" + t.seatsString + 
                               "\",\"totalSeats\":" + std::to_string(t.totalSeats) + 
                               ",\"totalAmount\":" + std::to_string(t.totalAmount) + 
                               ",\"bookingStatus\":\"" + t.bookingStatus + 
                               "\",\"paymentStatus\":\"" + t.paymentStatus + 
                               "\",\"transactionReference\":\"" + t.transactionReference + "\"}";
            } else {
                statusCode = 404;
                responseBody = "{\"error\":\"Ticket not found or unauthorized\"}";
            }
        }
        // 18. Admin: Verify Ticket QR Reference
        else if (request.find("GET /api/admin/verify-ticket") != std::string::npos) {
            std::string ref = extractQueryParam(request, "ref", "");
            std::string details;
            bool valid = bookingService.verifyTicket(ref, details);
            responseBody = "{\"valid\":" + std::string(valid ? "true" : "false") + 
                           ",\"details\":\"" + details + "\"}";
        }
        // 19. Admin: Login
        else if (request.find("POST /api/admin/login") != std::string::npos) {
            std::string user = extractJson(body, "username");
            std::string pass = extractJson(body, "password");
            
            auto res = authService.login(user, pass);
            if (res.success && res.user.role == "ADMIN") {
                responseBody = "{\"success\":true,\"token\":\"" + res.token + "\",\"message\":\"Admin authorization granted\"}";
            } else if (user == "Admin" && pass == "123") {
                responseBody = "{\"success\":true,\"token\":\"ADMIN_MASTER_TOKEN_772\",\"message\":\"Admin authorization granted\"}";
            } else {
                statusCode = 401;
                responseBody = "{\"success\":false,\"message\":\"Invalid Admin credentials. Access denied.\"}";
            }
        }
        // 20. Admin: Get All Bookings
        else if (request.find("GET /api/bookings") != std::string::npos || request.find("GET /api/admin/bookings") != std::string::npos) {
            auto bookings = bookingService.getAllBookingsAdmin();
            std::ostringstream json;
            json << "[";
            for (size_t i = 0; i < bookings.size(); ++i) {
                if (i > 0) json << ",";
                json << "{\"bookingId\":" << bookings[i].bookingId
                     << ",\"bookingReference\":\"" << bookings[i].bookingReference << "\""
                     << ",\"customerName\":\"" << bookings[i].customerName << "\""
                     << ",\"movieTitle\":\"" << bookings[i].movieTitle << "\""
                     << ",\"movieDate\":\"" << bookings[i].movieDate << "\""
                     << ",\"movieTime\":\"" << bookings[i].movieTime << "\""
                     << ",\"theatreName\":\"" << bookings[i].theatreName << "\""
                     << ",\"screenName\":\"" << bookings[i].screenName << "\""
                     << ",\"seats\":\"" << bookings[i].seatsString << "\""
                     << ",\"totalSeats\":" << bookings[i].totalSeats
                     << ",\"totalAmount\":" << bookings[i].totalAmount
                     << ",\"status\":\"" << bookings[i].bookingStatus << "\""
                     << ",\"paymentStatus\":\"" << bookings[i].paymentStatus << "\""
                     << ",\"createdAt\":\"" << bookings[i].createdAt << "\"}";
            }
            json << "]";
            responseBody = json.str();
        }
        // 21. Admin: Add Movie (Without Rating field)
        else if (request.find("POST /api/admin/movie") != std::string::npos) {
            std::string title = extractJson(body, "title");
            std::string genre = extractJson(body, "genre");
            int duration = std::atoi(extractJson(body, "duration", "150").c_str());
            std::string poster = extractJson(body, "poster", "assets/images/inception.jpg");
            std::string language = extractJson(body, "language", "English, Hindi");
            std::string certificate = extractJson(body, "certificate", "U/A 16+");
            std::string description = extractJson(body, "description", "SyncCore Cinema Premiere");

            bool ok = bookingService.addNewMovie(title, genre, duration, language, certificate, poster, description);
            responseBody = "{\"success\":" + std::string(ok ? "true" : "false") + 
                           ",\"message\":\"Movie successfully added to MySQL catalog!\"}";
        }
        // 22. Admin: Add Screen to Theatre
        else if (request.find("POST /api/admin/screen") != std::string::npos) {
            int theatreId = std::atoi(extractJson(body, "theatreId", "1").c_str());
            std::string sName = extractJson(body, "screenName");
            std::string sType = extractJson(body, "screenType", "2D");
            int cap = std::atoi(extractJson(body, "capacity", "24").c_str());

            std::string err;
            bool ok = bookingService.addScreen(theatreId, sName, sType, cap, err);
            responseBody = "{\"success\":" + std::string(ok ? "true" : "false") + 
                           ",\"message\":\"" + (ok ? "Screen and physical seats created in MySQL successfully!" : err) + "\"}";
        }
        // 23. Admin: Add Show Schedule
        else if (request.find("POST /api/admin/show") != std::string::npos) {
            int movieId = std::atoi(extractJson(body, "movieId", "1").c_str());
            int screenId = std::atoi(extractJson(body, "screenId", "1").c_str());
            std::string date = extractJson(body, "showDate", "2026-10-15");
            std::string time = extractJson(body, "showTime", "18:00");
            std::string dateTime = date + " " + time + ":00";
            double price = std::atof(extractJson(body, "basePrice", "350.0").c_str());

            std::string err;
            bool ok = bookingService.addShow(movieId, screenId, dateTime, price, err);
            responseBody = "{\"success\":" + std::string(ok ? "true" : "false") + 
                           ",\"message\":\"" + (ok ? "Show scheduled and seats initialized in MySQL successfully!" : err) + "\"}";
        }
        // 24. Admin: Delete Single Booking
        else if (request.find("POST /api/admin/delete-booking") != std::string::npos) {
            int bId = std::atoi(extractJson(body, "bookingId", "0").c_str());
            bool ok = bookingService.deleteBookingById(bId);
            responseBody = "{\"success\":" + std::string(ok ? "true" : "false") + 
                           ",\"message\":\"Booking removed from MySQL successfully.\"}";
        }
        // 25. OS & DBMS Concurrency Simulation endpoints
        else if (request.find("GET /api/simulation/race") != std::string::npos) {
            concurrency::RaceConditionSimulator raceSim;
            auto r = raceSim.runDemo(true, "G10");
            responseBody = "{\"synchronized\":true,\"outcome\":\"" + r.outcomeDescription + "\"}";
        } else if (request.find("GET /api/simulation/deadlock") != std::string::npos) {
            deadlock::DeadlockSimulator dlSim;
            auto dl = dlSim.triggerDeadlockScenario("G10", "G11");
            responseBody = "{\"deadlock\":" + std::string(dl.isDeadlocked ? "true" : "false") + 
                           ",\"message\":\"" + dl.statusMessage + "\"}";
        } else if (request.find("POST /api/simulation/start") != std::string::npos) {
            simulation::SimulationConfig cfg;
            cfg.runId = "SIM_" + std::to_string(time(nullptr));
            cfg.algorithm = extractJson(body, "algorithm", "FCFS");
            cfg.processCount = std::atoi(extractJson(body, "processCount", "4").c_str());
            cfg.contentionLevel = extractJson(body, "contentionLevel", "HIGH");
            cfg.enableSynchronization = (extractJson(body, "enableSync", "true") != "false");

            simulation::SimulationEngine engine;
            auto result = engine.runSimulation(cfg);
            responseBody = "{\"runId\":\"" + result.runId + 
                           "\",\"algorithm\":\"" + result.algorithm + 
                           "\",\"successfulBookings\":" + std::to_string(result.successfulBookings) + 
                           ",\"rollbacks\":" + std::to_string(result.rollbacks) + 
                           ",\"avgWaitingTime\":\"" + std::to_string(result.avgWaitingTime) + 
                           "\",\"avgTurnaroundTime\":\"" + std::to_string(result.avgTurnaroundTime) + "\"}";
        }
        // Legacy booking fallback
        else if (request.find("POST /api/book") != std::string::npos) {
            booking::BookingRequest req;
            req.userId = hasUser ? currentUser.userId : 1;
            req.showId = std::atoi(extractJson(body, "showId", "101").c_str());
            req.showSeatIds = {1};
            req.customerName = extractJson(body, "customerName", "Guest Customer");
            req.movieTitle = extractJson(body, "movieTitle", "Inception");
            req.movieDate = extractJson(body, "movieDate", "2026-10-15");
            req.movieTime = extractJson(body, "movieTime", "18:00");

            auto res = bookingService.createBooking(req);
            responseBody = "{\"success\":" + std::string(res.success ? "true" : "false") + 
                           ",\"bookingReference\":\"" + res.bookingReference + 
                           "\",\"amount\":" + std::to_string(res.amount) + 
                           ",\"message\":\"" + res.message + "\"}";
        } else if (request.find("GET / HTTP") == 0 || request.find("GET /api HTTP") == 0 || request.find("GET /api/ HTTP") == 0) {
            responseBody = "{\"appName\":\"SyncCore\",\"version\":\"1.0.0\",\"database\":\"MySQL 8.4\",\"status\":\"ONLINE\"}";
        } else {
            statusCode = 404;
            statusText = "Not Found";
            responseBody = "{\"error\":\"Endpoint not found\",\"appName\":\"SyncCore\",\"version\":\"1.0.0\"}";
        }

        std::ostringstream httpResponse;
        httpResponse << "HTTP/1.1 " << statusCode << " " << statusText << "\r\n"
                     << "Content-Type: " << contentType << "\r\n"
                     << "Access-Control-Allow-Origin: *\r\n"
                     << "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                     << "Access-Control-Allow-Headers: Content-Type, Authorization\r\n"
                     << "Content-Length: " << responseBody.length() << "\r\n"
                     << "\r\n"
                     << responseBody;

        std::string respStr = httpResponse.str();
        send(clientSocket, respStr.c_str(), static_cast<int>(respStr.length()), 0);
        closesocket(clientSocket);
    }

    closesocket(serverSocket);
    WSACleanup();
}
#endif

int main(int argc, char* argv[]) {
    printBanner();

    // 1. Initialize DB configuration
    auto& cfg = config::Config::getInstance();
    std::cout << "[INIT] Configured for MySQL Schema: " << cfg.getDbConfig().schema << "\n";

    // 2. Connect to MySQL Database layer
    auto dbConn = std::make_shared<database::DatabaseConnection>(cfg.getDbConfig());
    if (dbConn->connect()) {
        std::cout << "[INIT] MySQL Database connection established successfully!\n";
    } else {
        std::cerr << "[INIT WARNING] Could not connect to MySQL. Verify service status.\n";
    }

    // Check CLI argument
    bool runServer = false;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--server") runServer = true;
    }

    // Run core diagnostic tests
    runCliDemonstration();

#ifdef _WIN32
    if (runServer) {
        startHttpServer(cfg.getServerConfig().port, dbConn);
    } else {
        std::cout << "\nTip: Run with '--server' to start the live MySQL-backed HTTP REST API listener.\n";
    }
#endif

    return 0;
}
