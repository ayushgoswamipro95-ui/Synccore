#include "../../include/simulation/SimulationResult.h"

namespace synccore {
namespace simulation {

// Result structures for simulation output

} // namespace simulation
} // namespace synccore
