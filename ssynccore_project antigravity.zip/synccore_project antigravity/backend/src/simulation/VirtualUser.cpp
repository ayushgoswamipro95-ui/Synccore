#include "../../include/simulation/VirtualUser.h"

namespace synccore {
namespace simulation {

// Virtual user generation and state tracking

} // namespace simulation
} // namespace synccore
