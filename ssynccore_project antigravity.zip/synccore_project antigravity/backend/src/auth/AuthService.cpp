#include "../../include/auth/AuthService.h"
#include "../../include/crypto/Sha256.h"
#include <iostream>
#include <algorithm>
#include <cctype>
#include <regex>
#include <ctime>

namespace synccore {
namespace auth {

AuthService::AuthService(std::shared_ptr<database::DatabaseConnection> conn)
    : conn_(conn) {
    ensureDefaultAccounts();
}

std::string AuthService::normalizeEmail(const std::string& email) {
    std::string str = email;
    // Trim whitespace
    size_t start = str.find_first_not_of(" \t\r\n");
    size_t end = str.find_last_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    str = str.substr(start, end - start + 1);

    // Convert to lowercase
    std::transform(str.begin(), str.end(), str.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return str;
}

bool AuthService::validateEmail(const std::string& email) {
    std::string normalized = normalizeEmail(email);
    if (normalized.empty()) return false;
    // Standard email structure check: chars@chars.chars
    static const std::regex emailRegex(R"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)");
    return std::regex_match(normalized, emailRegex);
}

std::string AuthService::generateToken(int userId) {
    std::string salt = crypto::Sha256::generateSalt(12);
    return "token_u" + std::to_string(userId) + "_" + std::to_string(time(nullptr)) + "_" + salt;
}

void AuthService::ensureDefaultAccounts() {
    if (!conn_ || !conn_->isConnected()) return;

    // Check if admin password is hashed
    auto rows = conn_->query("SELECT user_id, password_hash FROM users WHERE username = 'Admin' OR username = 'ayush_admin' OR email = 'admin@synccore.com' LIMIT 1;");
    if (rows.empty()) {
        std::string hashed123 = crypto::Sha256::hashPassword("123");
        conn_->execute("INSERT INTO users (username, email, password_hash, full_name, role) VALUES ('Admin', 'admin@synccore.com', '" + hashed123 + "', 'System Administrator', 'ADMIN');");
        std::cout << "[AuthService] Default Administrator account provisioned (Admin / 123)\n";
    } else {
        std::string curHash = rows[0].get("password_hash");
        if (curHash.find('$') == std::string::npos) {
            // Upgrade plaintext legacy password to secure salt hash
            std::string hashed123 = crypto::Sha256::hashPassword(curHash.empty() ? "123" : curHash);
            conn_->execute("UPDATE users SET password_hash = '" + hashed123 + "' WHERE user_id = " + rows[0].get("user_id") + ";");
        }
    }
}

AuthResult AuthService::signup(const std::string& fullName, const std::string& email, const std::string& password, const std::string& phone) {
    AuthResult res;

    if (fullName.empty() || fullName.length() < 2) {
        res.success = false;
        res.message = "Full name must be at least 2 characters long.";
        return res;
    }

    if (!validateEmail(email)) {
        res.success = false;
        res.message = "Please provide a valid email address (e.g. user@gmail.com).";
        return res;
    }

    if (password.length() < 4) {
        res.success = false;
        res.message = "Password must be at least 4 characters long.";
        return res;
    }

    std::string normEmail = normalizeEmail(email);

    if (!conn_ || !conn_->isConnected()) {
        res.success = false;
        res.message = "Database offline. Please try again later.";
        return res;
    }

    // Check duplicate email
    auto existing = conn_->query("SELECT user_id FROM users WHERE LOWER(email) = '" + normEmail + "' LIMIT 1;");
    if (!existing.empty()) {
        res.success = false;
        res.message = "Email already registered. Please log in.";
        return res;
    }

    // Generate safe username from email
    size_t atPos = normEmail.find('@');
    std::string baseUser = normEmail.substr(0, atPos);
    std::string username = baseUser;

    auto userCheck = conn_->query("SELECT user_id FROM users WHERE username = '" + username + "' LIMIT 1;");
    if (!userCheck.empty()) {
        username = baseUser + "_" + std::to_string(time(nullptr) % 1000);
    }

    // Hash password with salt
    std::string passwordHash = crypto::Sha256::hashPassword(password);

    std::string insertSql = "INSERT INTO users (username, email, password_hash, full_name, role, phone) VALUES ('"
        + username + "', '" + normEmail + "', '" + passwordHash + "', '" + fullName + "', 'USER', '" + phone + "');";

    if (!conn_->execute(insertSql)) {
        res.success = false;
        res.message = "Failed to register account in database.";
        return res;
    }

    auto newRow = conn_->query("SELECT user_id, username, email, full_name, role, phone FROM users WHERE email = '" + normEmail + "' LIMIT 1;");
    if (newRow.empty()) {
        res.success = false;
        res.message = "Registration verification failed.";
        return res;
    }

    int uid = std::atoi(newRow[0].get("user_id").c_str());
    std::string token = generateToken(uid);

    UserSession sess;
    sess.userId = uid;
    sess.username = newRow[0].get("username");
    sess.email = newRow[0].get("email");
    sess.fullName = newRow[0].get("full_name");
    sess.role = newRow[0].get("role");
    sess.phone = newRow[0].get("phone");
    sess.token = token;

    {
        concurrency::SyncLockGuard lock(sessionMutex_);
        sessions_[token] = sess;
    }

    res.success = true;
    res.token = token;
    res.user = sess;
    res.message = "Account registered successfully!";
    std::cout << "[AuthService] New User Registered: " << normEmail << " (ID: " << uid << ")\n";
    return res;
}

AuthResult AuthService::login(const std::string& emailOrUser, const std::string& password) {
    AuthResult res;
    std::string identifier = normalizeEmail(emailOrUser);

    if (identifier.empty() || password.empty()) {
        res.success = false;
        res.message = "Email/Username and password are required.";
        return res;
    }

    if (!conn_ || !conn_->isConnected()) {
        // Fallback for admin if offline
        if (identifier == "admin" && password == "123") {
            res.success = true;
            res.token = "ADMIN_SESSION_TOKEN_OFFLINE";
            res.user = {1, "Admin", "admin@synccore.com", "System Administrator", "ADMIN", "", res.token};
            return res;
        }
        res.success = false;
        res.message = "Database connection offline.";
        return res;
    }

    std::string querySql = "SELECT user_id, username, email, password_hash, full_name, role, phone FROM users "
                           "WHERE LOWER(email) = '" + identifier + "' OR LOWER(username) = '" + identifier + "' LIMIT 1;";

    auto rows = conn_->query(querySql);
    if (rows.empty()) {
        res.success = false;
        res.message = "Invalid email or password.";
        return res;
    }

    std::string storedHash = rows[0].get("password_hash");
    bool match = crypto::Sha256::verifyPassword(password, storedHash);

    if (!match) {
        res.success = false;
        res.message = "Invalid email or password.";
        return res;
    }

    int uid = std::atoi(rows[0].get("user_id").c_str());
    std::string token = generateToken(uid);

    UserSession sess;
    sess.userId = uid;
    sess.username = rows[0].get("username");
    sess.email = rows[0].get("email");
    sess.fullName = rows[0].get("full_name");
    sess.role = rows[0].get("role");
    sess.phone = rows[0].get("phone");
    sess.token = token;

    {
        concurrency::SyncLockGuard lock(sessionMutex_);
        sessions_[token] = sess;
    }

    res.success = true;
    res.token = token;
    res.user = sess;
    res.message = "Login successful!";
    std::cout << "[AuthService] User Logged In: " << sess.email << " (Role: " << sess.role << ")\n";
    return res;
}

bool AuthService::logout(const std::string& token) {
    concurrency::SyncLockGuard lock(sessionMutex_);
    return sessions_.erase(token) > 0;
}

bool AuthService::getSession(const std::string& token, UserSession& outSession) {
    if (token.empty()) return false;
    concurrency::SyncLockGuard lock(sessionMutex_);
    auto it = sessions_.find(token);
    if (it != sessions_.end()) {
        outSession = it->second;
        return true;
    }

    // Auto-restore valid user session from database if server restarted
    if (token.rfind("token_u", 0) == 0 && conn_ && conn_->isConnected()) {
        size_t underPos = token.find('_', 7);
        if (underPos != std::string::npos) {
            std::string uidStr = token.substr(7, underPos - 7);
            int uid = std::atoi(uidStr.c_str());
            if (uid > 0) {
                auto rows = conn_->query("SELECT user_id, username, email, full_name, role, phone FROM users WHERE user_id = " + std::to_string(uid) + " LIMIT 1;");
                if (!rows.empty()) {
                    outSession.userId = uid;
                    outSession.username = rows[0].get("username");
                    outSession.email = rows[0].get("email");
                    outSession.fullName = rows[0].get("full_name");
                    outSession.role = rows[0].get("role");
                    outSession.phone = rows[0].get("phone");
                    outSession.token = token;
                    sessions_[token] = outSession;
                    return true;
                }
            }
        }
    }
    return false;
}

} // namespace auth
} // namespace synccore
