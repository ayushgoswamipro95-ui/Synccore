#include "../../include/concurrency/CriticalSection.h"

namespace synccore {
namespace concurrency {

CriticalSectionGuard::CriticalSectionGuard(const std::string& resourceId, int processId)
    : resourceId_(resourceId), processId_(processId), acquired_(false) {
    acquired_ = MutexManager::getInstance().lock(resourceId_, processId_);
}

CriticalSectionGuard::~CriticalSectionGuard() {
    if (acquired_) {
        MutexManager::getInstance().unlock(resourceId_, processId_);
    }
}

bool CriticalSection::executeGuarded(const std::string& resourceId, int processId, const std::function<bool()>& action) {
    CriticalSectionGuard guard(resourceId, processId);
    if (!guard.isAcquired()) return false;
    return action();
}

} // namespace concurrency
} // namespace synccore
