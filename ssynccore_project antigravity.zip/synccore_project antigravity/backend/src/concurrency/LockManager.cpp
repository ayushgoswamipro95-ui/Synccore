#include "../../include/concurrency/LockManager.h"

namespace synccore {
namespace concurrency {

bool LockManager::requestLock(const std::string& resourceId, int processId) {
    SyncLockGuard lock(mutex_);
    auto& resLock = locks_[resourceId];
    resLock.resourceIdentifier = resourceId;

    if (resLock.state == models::LockState::FREE || resLock.state == models::LockState::RELEASED) {
        resLock.state = models::LockState::ACQUIRED;
        resLock.holdingProcessId = processId;
        resLock.waitingProcessId = 0;
        return true;
    } else {
        resLock.waitingProcessId = processId;
        return false;
    }
}

bool LockManager::releaseLock(const std::string& resourceId, int processId) {
    SyncLockGuard lock(mutex_);
    auto it = locks_.find(resourceId);
    if (it == locks_.end() || it->second.holdingProcessId != processId) {
        return false;
    }
    it->second.state = models::LockState::RELEASED;
    it->second.holdingProcessId = 0;
    return true;
}

models::LockState LockManager::getLockState(const std::string& resourceId) const {
    SyncLockGuard lock(mutex_);
    auto it = locks_.find(resourceId);
    return (it != locks_.end()) ? it->second.state : models::LockState::FREE;
}

std::vector<models::ResourceLock> LockManager::getAllLocks() const {
    SyncLockGuard lock(mutex_);
    std::vector<models::ResourceLock> list;
    for (const auto& kv : locks_) {
        list.push_back(kv.second);
    }
    return list;
}

void LockManager::reset() {
    SyncLockGuard lock(mutex_);
    locks_.clear();
}

} // namespace concurrency
} // namespace synccore
