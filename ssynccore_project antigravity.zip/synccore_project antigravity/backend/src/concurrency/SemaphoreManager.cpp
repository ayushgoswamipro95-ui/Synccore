#include "../../include/concurrency/SemaphoreManager.h"

namespace synccore {
namespace concurrency {

void SemaphoreManager::registerSemaphore(const std::string& name, int initialCount) {
    SyncLockGuard lock(mutex_);
    semaphores_[name] = std::make_shared<CountingSemaphore>(initialCount);
}

bool SemaphoreManager::acquire(const std::string& name, int timeoutMs) {
    std::shared_ptr<CountingSemaphore> sem;
    {
        SyncLockGuard lock(mutex_);
        auto it = semaphores_.find(name);
        if (it == semaphores_.end()) return false;
        sem = it->second;
    }
    return sem->wait(timeoutMs);
}

void SemaphoreManager::release(const std::string& name) {
    std::shared_ptr<CountingSemaphore> sem;
    {
        SyncLockGuard lock(mutex_);
        auto it = semaphores_.find(name);
        if (it == semaphores_.end()) return;
        sem = it->second;
    }
    sem->signal();
}

int SemaphoreManager::getPermits(const std::string& name) {
    SyncLockGuard lock(mutex_);
    auto it = semaphores_.find(name);
    return (it != semaphores_.end()) ? it->second->getAvailablePermits() : 0;
}

void SemaphoreManager::reset() {
    SyncLockGuard lock(mutex_);
    semaphores_.clear();
}

} // namespace concurrency
} // namespace synccore
