#include "../../include/concurrency/RaceConditionSimulator.h"
#include "../../include/concurrency/MutexManager.h"
#include <sstream>

namespace synccore {
namespace concurrency {

RaceConditionResult RaceConditionSimulator::runDemo(bool enableSynchronization, const std::string& seatLabel) {
    RaceConditionResult result;
    result.synchronized = enableSynchronization;
    result.seatLabel = seatLabel;
    result.process1Id = 1;
    result.process2Id = 2;

    if (!enableSynchronization) {
        // Unsynchronized Race Condition demonstration:
        // Both P1 and P2 check AVAILABLE concurrently and both book!
        result.executionTrace.push_back("P1 checks seat " + seatLabel + " status: [AVAILABLE]");
        result.executionTrace.push_back("P2 checks seat " + seatLabel + " status: [AVAILABLE] (Race condition!)");
        result.executionTrace.push_back("P1 writes booking record for " + seatLabel);
        result.executionTrace.push_back("P2 writes booking record for " + seatLabel + " (ANOMALY: Double-booked!)");
        
        result.process1Success = true;
        result.process2Success = true; // Flawed double booking
        result.outcomeDescription = "RACE CONDITION OCCURRED! Both P1 and P2 booked the exact same seat " + seatLabel + " resulting in database inconsistency!";
    } else {
        // Synchronized with Mutex:
        result.executionTrace.push_back("P1 requests Mutex for seat " + seatLabel + " -> LOCK ACQUIRED");
        result.executionTrace.push_back("P2 requests Mutex for seat " + seatLabel + " -> LOCK WAITING (Blocked)");
        result.executionTrace.push_back("P1 checks seat " + seatLabel + " -> [AVAILABLE]");
        result.executionTrace.push_back("P1 books seat " + seatLabel + " -> COMMIT");
        result.executionTrace.push_back("P1 releases Mutex for seat " + seatLabel + " -> LOCK RELEASED");
        result.executionTrace.push_back("P2 unblocked -> checks seat " + seatLabel + " -> [ALREADY BOOKED]");
        result.executionTrace.push_back("P2 booking rejected -> ROLLBACK cleanly");

        result.process1Success = true;
        result.process2Success = false;
        result.outcomeDescription = "SYNCHRONIZATION ENFORCED. P1 successfully acquired lock and booked " + seatLabel + ". P2 gracefully rolled back.";
    }

    return result;
}

} // namespace concurrency
} // namespace synccore
