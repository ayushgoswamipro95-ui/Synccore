#include "../../include/concurrency/MutexManager.h"

namespace synccore {
namespace concurrency {

bool MutexManager::lock(const std::string& resourceId, int processId) {
    SyncLockGuard lock(globalMutex_);
    auto it = locks_.find(resourceId);
    if (it != locks_.end()) {
        if (it->second == processId) return true; // Reentrant for same process
        return false; // Already locked by another process
    }
    locks_[resourceId] = processId;
    return true;
}

bool MutexManager::tryLock(const std::string& resourceId, int processId) {
    return lock(resourceId, processId);
}

bool MutexManager::unlock(const std::string& resourceId, int processId) {
    SyncLockGuard lock(globalMutex_);
    auto it = locks_.find(resourceId);
    if (it == locks_.end() || it->second != processId) {
        return false;
    }
    locks_.erase(it);
    return true;
}

bool MutexManager::isLocked(const std::string& resourceId) const {
    SyncLockGuard lock(globalMutex_);
    return locks_.find(resourceId) != locks_.end();
}

int MutexManager::getHolder(const std::string& resourceId) const {
    SyncLockGuard lock(globalMutex_);
    auto it = locks_.find(resourceId);
    return (it != locks_.end()) ? it->second : 0;
}

void MutexManager::reset() {
    SyncLockGuard lock(globalMutex_);
    locks_.clear();
}

} // namespace concurrency
} // namespace synccore
