#include "../../include/booking/SeatService.h"
#include <iostream>
#include <cstdlib>

namespace synccore {
namespace booking {

SeatService::SeatService(std::shared_ptr<database::DatabaseConnection> conn)
    : conn_(conn) {}

std::vector<models::ShowSeat> SeatService::getSeatsForShow(int showId) {
    std::vector<models::ShowSeat> seats;

    // 1. Fetch live from MySQL
    if (conn_ && conn_->isConnected()) {
        std::string sql = "SELECT ss.show_seat_id, ss.show_id, ss.seat_id, s.seat_label, s.seat_type, ss.price, ss.status "
                          "FROM show_seats ss JOIN seats s ON ss.seat_id = s.seat_id "
                          "WHERE ss.show_id = " + std::to_string(showId) + " ORDER BY ss.show_seat_id ASC;";
        auto rows = conn_->query(sql);
        for (const auto& r : rows) {
            models::ShowSeat s;
            s.showSeatId = std::atoi(r.get("show_seat_id", "0").c_str());
            s.showId = std::atoi(r.get("show_id", "0").c_str());
            s.seatId = std::atoi(r.get("seat_id", "0").c_str());
            s.seatLabel = r.get("seat_label");
            s.seatType = r.get("seat_type");
            s.price = std::atof(r.get("price", "300.0").c_str());
            s.status = r.get("status", "AVAILABLE");
            seats.push_back(s);
        }
        if (!seats.empty()) {
            std::cout << "[SeatService] Loaded " << seats.size() << " live seats from MySQL for show " << showId << std::endl;
            return seats;
        }
    }

    // 2. Default layout fallback
    std::string rows[] = {"A", "B", "C", "G"};
    int id = 1;
    for (const auto& r : rows) {
        for (int i = 1; i <= 6; ++i) {
            models::ShowSeat s;
            s.showSeatId = id++;
            s.showId = showId;
            s.seatId = id;
            s.seatLabel = (r == "G") ? ("G" + std::to_string(9 + i)) : (r + std::to_string(i));
            s.seatType = (r == "G") ? "VIP" : ((r == "C") ? "PREMIUM" : "STANDARD");
            s.price = (r == "G") ? 450.0 : ((r == "C") ? 380.0 : 300.0);
            s.status = "AVAILABLE";
            seats.push_back(s);
        }
    }
    return seats;
}

bool SeatService::checkSeatAvailability(int showSeatId) {
    if (conn_ && conn_->isConnected()) {
        std::string sql = "SELECT status FROM show_seats WHERE show_seat_id = " + std::to_string(showSeatId) + ";";
        auto rows = conn_->query(sql);
        if (!rows.empty()) {
            return rows[0].get("status") == "AVAILABLE";
        }
    }
    return true;
}

bool SeatService::lockSeat(int showSeatId, int lockDurationSeconds) {
    std::cout << "[SeatService] Locking show_seat " << showSeatId << " for " << lockDurationSeconds << "s\n";
    if (conn_ && conn_->isConnected()) {
        std::string sql = "UPDATE show_seats SET status = 'LOCKED' WHERE show_seat_id = " + std::to_string(showSeatId) + ";";
        return conn_->execute(sql);
    }
    return true;
}

bool SeatService::releaseSeat(int showSeatId) {
    std::cout << "[SeatService] Releasing show_seat " << showSeatId << "\n";
    if (conn_ && conn_->isConnected()) {
        std::string sql = "UPDATE show_seats SET status = 'AVAILABLE' WHERE show_seat_id = " + std::to_string(showSeatId) + " AND status = 'LOCKED';";
        return conn_->execute(sql);
    }
    return true;
}

} // namespace booking
} // namespace synccore
