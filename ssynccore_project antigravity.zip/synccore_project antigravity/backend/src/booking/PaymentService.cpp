#include "../../include/booking/PaymentService.h"

namespace synccore {
namespace booking {

PaymentService::PaymentResult PaymentService::processSimulatedPayment(int bookingId, double amount, const std::string& method) {
    PaymentResult res;
    res.success = true;
    res.transactionRef = "TXN_SIM_" + std::to_string(bookingId);
    res.responseCode = "200_OK";
    res.message = "Payment authorized successfully";
    return res;
}

PaymentService::PaymentResult PaymentService::refundPayment(const std::string& transactionRef) {
    PaymentResult res;
    res.success = true;
    res.transactionRef = transactionRef;
    res.responseCode = "REFUNDED";
    res.message = "Refund processed successfully";
    return res;
}

} // namespace booking
} // namespace synccore
