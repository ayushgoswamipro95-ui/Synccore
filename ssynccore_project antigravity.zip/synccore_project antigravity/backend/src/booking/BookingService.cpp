#include "../../include/booking/BookingService.h"
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <algorithm>

namespace synccore {
namespace booking {

BookingService::BookingService(std::shared_ptr<database::DatabaseConnection> conn)
    : conn_(conn) {}

BookingResult BookingService::createPendingReservation(const BookingRequest& req) {
    BookingResult result;
    result.customerName = req.customerName;
    result.customerEmail = req.customerEmail;
    result.movieTitle = req.movieTitle;
    result.movieDate = req.movieDate;
    result.movieTime = req.movieTime;

    if (!conn_ || !conn_->isConnected()) {
        result.success = false;
        result.message = "Database connection offline";
        return result;
    }

    if (req.userId <= 0) {
        result.success = false;
        result.message = "Authentication required. Please log in to complete booking.";
        return result;
    }

    if (req.showSeatIds.empty()) {
        result.success = false;
        result.message = "No seats selected.";
        return result;
    }

    std::cout << "[BookingService] Initiating Seat Reservation for User #" << req.userId 
              << ", Show #" << req.showId << " (" << req.showSeatIds.size() << " seats)\n";

    // 1. START TRANSACTION
    if (!conn_->beginTransaction()) {
        result.success = false;
        result.message = "Failed to begin reservation transaction";
        return result;
    }

    // 2. Row Lock & Seat Availability Check (SELECT ... FOR UPDATE)
    double calculatedTotal = 0.0;
    for (int seatId : req.showSeatIds) {
        std::string checkSql = "SELECT show_seat_id, price, status FROM show_seats WHERE show_seat_id = " 
                               + std::to_string(seatId) + " FOR UPDATE;";
        auto rows = conn_->query(checkSql);
        if (rows.empty()) {
            conn_->rollback();
            result.success = false;
            result.message = "Invalid seat selection.";
            return result;
        }

        std::string status = rows[0].get("status");
        if (status != "AVAILABLE") {
            conn_->rollback();
            result.success = false;
            result.message = "Seat contention conflict: One or more selected seats are already locked or booked.";
            std::cout << "[BookingService] CONFLICT: Seat " << seatId << " status is " << status << ". Aborting.\n";
            return result;
        }

        double seatPrice = std::atof(rows[0].get("price", "350.0").c_str());
        calculatedTotal += seatPrice;
    }

    // Add standard convenience fee
    calculatedTotal += 45.00;

    // 3. Mark seats as LOCKED temporarily for 10 minutes checkout window
    for (int seatId : req.showSeatIds) {
        std::string lockSql = "UPDATE show_seats SET status = 'LOCKED', lock_expires_at = DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE show_seat_id = " 
                              + std::to_string(seatId) + ";";
        conn_->execute(lockSql);
    }

    // 4. Generate Booking Reference and Insert PENDING Booking Record
    std::string ref = "BK-" + std::to_string(time(nullptr) % 900000 + 100000);
    std::string safeTitle = req.movieTitle.empty() ? "SyncCore Premiere" : req.movieTitle;
    std::string safeDate = req.movieDate.empty() ? "2026-10-15" : req.movieDate;
    std::string safeTime = req.movieTime.empty() ? "18:00" : req.movieTime;

    std::string insertBooking = "INSERT INTO bookings (user_id, show_id, booking_reference, total_seats, total_amount, booking_status, customer_name, movie_title, movie_date, movie_time) VALUES (" 
        + std::to_string(req.userId) + ", " 
        + std::to_string(req.showId) + ", '" 
        + ref + "', " 
        + std::to_string(req.showSeatIds.size()) + ", " 
        + std::to_string(calculatedTotal) + ", 'PENDING', '"
        + req.customerName + "', '"
        + safeTitle + "', '"
        + safeDate + "', '"
        + safeTime + "');";

    if (!conn_->execute(insertBooking)) {
        conn_->rollback();
        result.success = false;
        result.message = "Failed to create reservation record.";
        return result;
    }

    // Retrieve inserted booking_id
    auto bRows = conn_->query("SELECT booking_id FROM bookings WHERE booking_reference = '" + ref + "' LIMIT 1;");
    int bookingId = bRows.empty() ? 0 : std::atoi(bRows[0].get("booking_id").c_str());

    if (bookingId <= 0) {
        conn_->rollback();
        result.success = false;
        result.message = "Failed to retrieve booking identifier.";
        return result;
    }

    // 5. Insert Junction Records into booking_seats
    for (int seatId : req.showSeatIds) {
        std::string insJunction = "INSERT INTO booking_seats (booking_id, show_seat_id) VALUES (" 
                                  + std::to_string(bookingId) + ", " + std::to_string(seatId) + ");";
        conn_->execute(insJunction);
    }

    // 6. Insert Initial Transaction Record with status CREATED
    std::string txnRef = "TXN-" + std::to_string(time(nullptr) % 900000 + 100000);
    std::string insTxn = "INSERT INTO transactions (transaction_reference, booking_id, amount, payment_method, payment_status, gateway_name) VALUES ('"
                         + txnRef + "', " + std::to_string(bookingId) + ", " + std::to_string(calculatedTotal) + ", 'UPI', 'CREATED', 'RAZORPAY');";
    conn_->execute(insTxn);

    // COMMIT Reservation Boundary
    if (conn_->commit()) {
        result.success = true;
        result.bookingId = bookingId;
        result.bookingReference = ref;
        result.amount = calculatedTotal;
        result.transactionReference = txnRef;
        result.message = "Seats temporarily reserved. Ready for Razorpay payment.";
        std::cout << "[BookingService] Reservation COMMITTED: Reference " << ref << " (ID: " << bookingId << ")\n";
    } else {
        conn_->rollback();
        result.success = false;
        result.message = "Commit failed during seat reservation.";
    }

    return result;
}

BookingResult BookingService::confirmBookingPayment(int bookingId, int userId, const std::string& gatewayOrderId, const std::string& gatewayPaymentId, const std::string& gatewaySignature) {
    BookingResult result;
    result.bookingId = bookingId;

    if (!conn_ || !conn_->isConnected()) {
        result.success = false;
        result.message = "Database offline";
        return result;
    }

    // Check booking ownership and state
    std::string checkSql = "SELECT booking_id, booking_reference, total_amount, booking_status, customer_name, movie_title, movie_date, movie_time "
                           "FROM bookings WHERE booking_id = " + std::to_string(bookingId) + " AND user_id = " + std::to_string(userId) + " FOR UPDATE;";
    
    if (!conn_->beginTransaction()) {
        result.success = false;
        result.message = "Failed to start payment commit transaction";
        return result;
    }

    auto rows = conn_->query(checkSql);
    if (rows.empty()) {
        conn_->rollback();
        result.success = false;
        result.message = "Booking record not found or unauthorized access.";
        return result;
    }

    std::string currentStatus = rows[0].get("booking_status");
    result.bookingReference = rows[0].get("booking_reference");
    result.amount = std::atof(rows[0].get("total_amount", "0").c_str());
    result.customerName = rows[0].get("customer_name");
    result.movieTitle = rows[0].get("movie_title");
    result.movieDate = rows[0].get("movie_date");
    result.movieTime = rows[0].get("movie_time");

    // Idempotency: If already confirmed, return success without re-executing
    if (currentStatus == "CONFIRMED") {
        conn_->commit();
        result.success = true;
        result.message = "Booking is already confirmed.";
        return result;
    }

    if (currentStatus != "PENDING") {
        conn_->rollback();
        result.success = false;
        result.message = "Booking is in an invalid state: " + currentStatus;
        return result;
    }

    // 1. Update Booking Status to CONFIRMED
    conn_->execute("UPDATE bookings SET booking_status = 'CONFIRMED' WHERE booking_id = " + std::to_string(bookingId) + ";");

    // 2. Transition Show Seats from LOCKED to BOOKED
    conn_->execute("UPDATE show_seats SET status = 'BOOKED', lock_expires_at = NULL WHERE show_seat_id IN ("
                   "SELECT show_seat_id FROM booking_seats WHERE booking_id = " + std::to_string(bookingId) + ");");

    // 3. Update Transaction Record to SUCCESS with Razorpay details
    std::string updateTxn = "UPDATE transactions SET payment_status = 'SUCCESS', "
                            "gateway_order_id = '" + gatewayOrderId + "', "
                            "gateway_payment_id = '" + gatewayPaymentId + "', "
                            "gateway_signature = '" + gatewaySignature + "' "
                            "WHERE booking_id = " + std::to_string(bookingId) + ";";
    conn_->execute(updateTxn);

    if (conn_->commit()) {
        result.success = true;
        result.message = "Payment verified and booking confirmed under ACID isolation.";
        std::cout << "[BookingService] Booking " << result.bookingReference << " successfully CONFIRMED via Razorpay (" << gatewayPaymentId << ")\n";
    } else {
        conn_->rollback();
        result.success = false;
        result.message = "Failed to commit booking confirmation.";
    }

    return result;
}

bool BookingService::rollbackFailedPayment(int bookingId, int userId, const std::string& reason) {
    if (!conn_ || !conn_->isConnected()) return false;
    std::cout << "[BookingService] Rolling back failed/cancelled booking #" << bookingId << " (Reason: " << reason << ")\n";

    if (!conn_->beginTransaction()) return false;

    // Release show seats back to AVAILABLE
    conn_->execute("UPDATE show_seats SET status = 'AVAILABLE', lock_expires_at = NULL WHERE show_seat_id IN ("
                   "SELECT show_seat_id FROM booking_seats WHERE booking_id = " + std::to_string(bookingId) + ");");

    // Update booking and transaction to FAILED
    conn_->execute("UPDATE bookings SET booking_status = 'FAILED' WHERE booking_id = " + std::to_string(bookingId) + " AND user_id = " + std::to_string(userId) + ";");
    conn_->execute("UPDATE transactions SET payment_status = 'FAILED' WHERE booking_id = " + std::to_string(bookingId) + ";");

    return conn_->commit();
}

bool BookingService::cancelBookingByUser(int bookingId, int userId, std::string& outMsg) {
    if (!conn_ || !conn_->isConnected()) {
        outMsg = "Database offline";
        return false;
    }

    std::string checkSql = "SELECT booking_id, booking_status FROM bookings WHERE booking_id = " 
                           + std::to_string(bookingId) + " AND user_id = " + std::to_string(userId) + ";";
    auto rows = conn_->query(checkSql);
    if (rows.empty()) {
        outMsg = "Booking not found or you are not authorized to cancel this ticket.";
        return false;
    }

    std::string currentStatus = rows[0].get("booking_status");
    if (currentStatus == "CANCELLED") {
        outMsg = "Booking is already cancelled.";
        return false;
    }

    if (!conn_->beginTransaction()) {
        outMsg = "Failed to start cancellation transaction.";
        return false;
    }

    // 1. Set booking status to CANCELLED
    conn_->execute("UPDATE bookings SET booking_status = 'CANCELLED' WHERE booking_id = " + std::to_string(bookingId) + ";");

    // 2. Restore show seats to AVAILABLE
    conn_->execute("UPDATE show_seats SET status = 'AVAILABLE', lock_expires_at = NULL WHERE show_seat_id IN ("
                   "SELECT show_seat_id FROM booking_seats WHERE booking_id = " + std::to_string(bookingId) + ");");

    // 3. Mark transaction as REFUNDED
    conn_->execute("UPDATE transactions SET payment_status = 'REFUNDED' WHERE booking_id = " + std::to_string(bookingId) + ";");

    if (conn_->commit()) {
        outMsg = "Booking cancelled successfully. Seats have been restored to available.";
        std::cout << "[BookingService] Booking #" << bookingId << " CANCELLED by User #" << userId << "\n";
        return true;
    } else {
        conn_->rollback();
        outMsg = "Failed to commit cancellation.";
        return false;
    }
}

std::vector<models::Booking> BookingService::getUserBookingsDetailed(int userId) {
    std::vector<models::Booking> list;
    if (!conn_ || !conn_->isConnected()) return list;

    std::string sql = 
        "SELECT b.booking_id, b.booking_reference, b.user_id, b.show_id, b.total_seats, b.total_amount, "
        "b.booking_status, b.customer_name, b.movie_title, b.movie_date, b.movie_time, b.created_at, "
        "COALESCE(m.poster_url, 'assets/images/inception.jpg') as poster_url, "
        "COALESCE(sc.screen_name, 'Screen 1') as screen_name, "
        "COALESCE(t.name, 'SyncCore Cinema') as theatre_name, "
        "COALESCE(tx.payment_status, 'SUCCESS') as payment_status, "
        "COALESCE(tx.transaction_reference, '') as transaction_reference, "
        "(SELECT GROUP_CONCAT(s.seat_label ORDER BY s.seat_label ASC SEPARATOR ', ') "
        " FROM booking_seats bs "
        " JOIN show_seats ss ON bs.show_seat_id = ss.show_seat_id "
        " JOIN seats s ON ss.seat_id = s.seat_id "
        " WHERE bs.booking_id = b.booking_id) as seat_labels "
        "FROM bookings b "
        "LEFT JOIN shows sh ON b.show_id = sh.show_id "
        "LEFT JOIN movies m ON sh.movie_id = m.movie_id "
        "LEFT JOIN screens sc ON sh.screen_id = sc.screen_id "
        "LEFT JOIN theatres t ON sc.theatre_id = t.theatre_id "
        "LEFT JOIN transactions tx ON b.booking_id = tx.booking_id "
        "WHERE b.user_id = " + std::to_string(userId) + " "
        "ORDER BY b.booking_id DESC;";

    auto rows = conn_->query(sql);
    for (const auto& r : rows) {
        models::Booking b;
        b.bookingId = std::atoi(r.get("booking_id", "0").c_str());
        b.bookingReference = r.get("booking_reference");
        b.userId = std::atoi(r.get("user_id", "0").c_str());
        b.showId = std::atoi(r.get("show_id", "0").c_str());
        b.customerName = r.get("customer_name");
        b.movieTitle = r.get("movie_title");
        b.movieDate = r.get("movie_date");
        b.movieTime = r.get("movie_time");
        b.showTime = b.movieDate + " " + b.movieTime;
        b.totalSeats = std::atoi(r.get("total_seats", "1").c_str());
        b.totalAmount = std::atof(r.get("total_amount", "0.0").c_str());
        b.bookingStatus = r.get("booking_status");
        b.paymentStatus = r.get("payment_status");
        b.posterUrl = r.get("poster_url");
        b.screenName = r.get("screen_name");
        b.theatreName = r.get("theatre_name");
        b.seatsString = r.get("seat_labels");
        if (b.seatsString.empty()) b.seatsString = "Reserved Seats";
        b.transactionReference = r.get("transaction_reference");
        b.createdAt = r.get("created_at");
        list.push_back(b);
    }

    return list;
}

std::vector<models::Booking> BookingService::getAllBookingsAdmin() {
    std::vector<models::Booking> list;
    if (!conn_ || !conn_->isConnected()) return list;

    std::string sql = 
        "SELECT b.booking_id, b.booking_reference, b.user_id, b.show_id, b.total_seats, b.total_amount, "
        "b.booking_status, b.customer_name, b.movie_title, b.movie_date, b.movie_time, b.created_at, "
        "COALESCE(sc.screen_name, 'Screen 1') as screen_name, "
        "COALESCE(t.name, 'SyncCore Cinema') as theatre_name, "
        "COALESCE(tx.payment_status, 'SUCCESS') as payment_status, "
        "(SELECT GROUP_CONCAT(s.seat_label SEPARATOR ', ') "
        " FROM booking_seats bs "
        " JOIN show_seats ss ON bs.show_seat_id = ss.show_seat_id "
        " JOIN seats s ON ss.seat_id = s.seat_id "
        " WHERE bs.booking_id = b.booking_id) as seat_labels "
        "FROM bookings b "
        "LEFT JOIN shows sh ON b.show_id = sh.show_id "
        "LEFT JOIN screens sc ON sh.screen_id = sc.screen_id "
        "LEFT JOIN theatres t ON sc.theatre_id = t.theatre_id "
        "LEFT JOIN transactions tx ON b.booking_id = tx.booking_id "
        "ORDER BY b.booking_id DESC;";

    auto rows = conn_->query(sql);
    for (const auto& r : rows) {
        models::Booking b;
        b.bookingId = std::atoi(r.get("booking_id", "0").c_str());
        b.bookingReference = r.get("booking_reference");
        b.userId = std::atoi(r.get("user_id", "0").c_str());
        b.customerName = r.get("customer_name");
        b.movieTitle = r.get("movie_title");
        b.movieDate = r.get("movie_date");
        b.movieTime = r.get("movie_time");
        b.showTime = b.movieDate + " " + b.movieTime;
        b.totalSeats = std::atoi(r.get("total_seats", "1").c_str());
        b.totalAmount = std::atof(r.get("total_amount", "0.0").c_str());
        b.bookingStatus = r.get("booking_status");
        b.paymentStatus = r.get("payment_status");
        b.screenName = r.get("screen_name");
        b.theatreName = r.get("theatre_name");
        b.seatsString = r.get("seat_labels");
        b.createdAt = r.get("created_at");
        list.push_back(b);
    }

    return list;
}

bool BookingService::deleteBookingById(int bookingId) {
    if (!conn_ || !conn_->isConnected()) return false;
    std::cout << "[Admin] Deleting booking #" << bookingId << " from MySQL...\n";

    // Restore show seats to available
    conn_->execute("UPDATE show_seats SET status = 'AVAILABLE', lock_expires_at = NULL WHERE show_seat_id IN ("
                   "SELECT show_seat_id FROM booking_seats WHERE booking_id = " + std::to_string(bookingId) + ");");

    conn_->execute("DELETE FROM booking_seats WHERE booking_id = " + std::to_string(bookingId) + ";");
    conn_->execute("DELETE FROM transactions WHERE booking_id = " + std::to_string(bookingId) + ";");
    return conn_->execute("DELETE FROM bookings WHERE booking_id = " + std::to_string(bookingId) + ";");
}

models::Booking BookingService::getTicketDetails(int bookingId, int userId, bool isAdmin) {
    models::Booking b;
    if (!conn_ || !conn_->isConnected()) return b;

    std::string userCondition = isAdmin ? "" : (" AND b.user_id = " + std::to_string(userId));
    std::string sql = 
        "SELECT b.booking_id, b.booking_reference, b.user_id, b.show_id, b.total_seats, b.total_amount, "
        "b.booking_status, b.customer_name, b.movie_title, b.movie_date, b.movie_time, b.created_at, "
        "u.email as customer_email, "
        "COALESCE(m.poster_url, 'assets/images/inception.jpg') as poster_url, "
        "COALESCE(sc.screen_name, 'Screen 1') as screen_name, "
        "COALESCE(t.name, 'SyncCore Cinema') as theatre_name, "
        "COALESCE(t.city, 'Delhi-NCR') as theatre_city, "
        "COALESCE(tx.payment_status, 'SUCCESS') as payment_status, "
        "COALESCE(tx.transaction_reference, '') as transaction_reference, "
        "(SELECT GROUP_CONCAT(s.seat_label ORDER BY s.seat_label ASC SEPARATOR ', ') "
        " FROM booking_seats bs "
        " JOIN show_seats ss ON bs.show_seat_id = ss.show_seat_id "
        " JOIN seats s ON ss.seat_id = s.seat_id "
        " WHERE bs.booking_id = b.booking_id) as seat_labels "
        "FROM bookings b "
        "JOIN users u ON b.user_id = u.user_id "
        "LEFT JOIN shows sh ON b.show_id = sh.show_id "
        "LEFT JOIN movies m ON sh.movie_id = m.movie_id "
        "LEFT JOIN screens sc ON sh.screen_id = sc.screen_id "
        "LEFT JOIN theatres t ON sc.theatre_id = t.theatre_id "
        "LEFT JOIN transactions tx ON b.booking_id = tx.booking_id "
        "WHERE b.booking_id = " + std::to_string(bookingId) + userCondition + " LIMIT 1;";

    auto rows = conn_->query(sql);
    if (!rows.empty()) {
        const auto& r = rows[0];
        b.bookingId = std::atoi(r.get("booking_id").c_str());
        b.bookingReference = r.get("booking_reference");
        b.userId = std::atoi(r.get("user_id").c_str());
        b.customerName = r.get("customer_name");
        b.customerEmail = r.get("customer_email");
        b.movieTitle = r.get("movie_title");
        b.movieDate = r.get("movie_date");
        b.movieTime = r.get("movie_time");
        b.showTime = b.movieDate + " " + b.movieTime;
        b.totalSeats = std::atoi(r.get("total_seats", "1").c_str());
        b.totalAmount = std::atof(r.get("total_amount", "0.0").c_str());
        b.bookingStatus = r.get("booking_status");
        b.paymentStatus = r.get("payment_status");
        b.posterUrl = r.get("poster_url");
        b.screenName = r.get("screen_name");
        b.theatreName = r.get("theatre_name") + " (" + r.get("theatre_city") + ")";
        b.seatsString = r.get("seat_labels");
        b.transactionReference = r.get("transaction_reference");
        b.createdAt = r.get("created_at");
    }

    return b;
}

bool BookingService::verifyTicket(const std::string& ticketRef, std::string& outDetails) {
    if (!conn_ || !conn_->isConnected()) {
        outDetails = "Database offline.";
        return false;
    }

    std::string sql = "SELECT b.booking_id, b.booking_reference, b.booking_status, b.customer_name, b.movie_title, "
                      "b.movie_date, b.movie_time, tx.payment_status "
                      "FROM bookings b "
                      "LEFT JOIN transactions tx ON b.booking_id = tx.booking_id "
                      "WHERE b.booking_reference = '" + ticketRef + "' LIMIT 1;";

    auto rows = conn_->query(sql);
    if (rows.empty()) {
        outDetails = "INVALID TICKET: Reference " + ticketRef + " does not exist.";
        return false;
    }

    std::string bStatus = rows[0].get("booking_status");
    std::string pStatus = rows[0].get("payment_status");

    if (bStatus == "CONFIRMED" && pStatus == "SUCCESS") {
        outDetails = "VALID TICKET: " + rows[0].get("movie_title") + " on " + rows[0].get("movie_date") + " " + rows[0].get("movie_time") + " for " + rows[0].get("customer_name");
        return true;
    } else if (bStatus == "CANCELLED") {
        outDetails = "CANCELLED TICKET: This booking was cancelled.";
        return false;
    } else {
        outDetails = "UNCONFIRMED TICKET: Payment status is " + pStatus + " (Booking " + bStatus + ")";
        return false;
    }
}

bool BookingService::addNewMovie(const std::string& title, const std::string& genre, int duration, const std::string& language, const std::string& certificate, const std::string& posterUrl, const std::string& description) {
    if (!conn_ || !conn_->isConnected()) return false;
    if (title.empty() || genre.empty() || duration <= 0) return false;

    std::string safePoster = posterUrl.empty() ? "assets/images/inception.jpg" : posterUrl;
    std::string safeLang = language.empty() ? "English, Hindi" : language;
    std::string safeCert = certificate.empty() ? "U/A 16+" : certificate;
    std::string safeDesc = description.empty() ? "Blockbuster Cinema Screening at SyncCore." : description;

    std::string sql = "INSERT INTO movies (title, genre, duration_minutes, rating, poster_url, description, certificate, language) VALUES ('"
        + title + "', '"
        + genre + "', "
        + std::to_string(duration) + ", '8.5', '"
        + safePoster + "', '"
        + safeDesc + "', '"
        + safeCert + "', '"
        + safeLang + "');";

    return conn_->execute(sql);
}

bool BookingService::addScreen(int theatreId, const std::string& screenName, const std::string& screenType, int capacity, std::string& outError) {
    if (!conn_ || !conn_->isConnected()) {
        outError = "Database offline.";
        return false;
    }

    if (theatreId <= 0 || screenName.empty()) {
        outError = "Theatre and screen name are required.";
        return false;
    }

    // Check duplicate screen in SAME theatre
    std::string dupCheck = "SELECT screen_id FROM screens WHERE theatre_id = " + std::to_string(theatreId) + " AND LOWER(screen_name) = LOWER('" + screenName + "') LIMIT 1;";
    auto existing = conn_->query(dupCheck);
    if (!existing.empty()) {
        outError = "A screen with name '" + screenName + "' already exists in this theatre.";
        return false;
    }

    // Determine next screen number
    auto numRows = conn_->query("SELECT COALESCE(MAX(screen_number), 0) + 1 as next_num FROM screens WHERE theatre_id = " + std::to_string(theatreId) + ";");
    int nextNum = numRows.empty() ? 1 : std::atoi(numRows[0].get("next_num", "1").c_str());

    std::string safeType = screenType.empty() ? "2D" : screenType;
    int cap = (capacity > 0) ? capacity : 24;

    std::string insertSql = "INSERT INTO screens (theatre_id, screen_number, screen_name, total_capacity, screen_type) VALUES ("
        + std::to_string(theatreId) + ", "
        + std::to_string(nextNum) + ", '"
        + screenName + "', "
        + std::to_string(cap) + ", '"
        + safeType + "');";

    if (!conn_->execute(insertSql)) {
        outError = "Failed to insert screen record into MySQL.";
        return false;
    }

    // Retrieve inserted screen_id
    auto sRows = conn_->query("SELECT screen_id FROM screens WHERE theatre_id = " + std::to_string(theatreId) + " AND screen_number = " + std::to_string(nextNum) + " LIMIT 1;");
    if (sRows.empty()) {
        outError = "Screen created, but could not retrieve generated ID.";
        return false;
    }
    int newScreenId = std::atoi(sRows[0].get("screen_id").c_str());

    // Generate standard 24 seats:
    // Rows A-C: STANDARD (1-6)
    // Rows D-F: PREMIUM (1-6)
    // Row G: VIP (10-15)
    std::string seatSql = "INSERT INTO seats (screen_id, row_name, seat_number, seat_label, seat_type) VALUES ";
    bool first = true;

    // Standard A, B, C
    std::string stdRows[] = {"A", "B", "C"};
    for (const auto& r : stdRows) {
        for (int i = 1; i <= 6; ++i) {
            if (!first) seatSql += ", ";
            first = false;
            seatSql += "(" + std::to_string(newScreenId) + ", '" + r + "', " + std::to_string(i) + ", '" + r + std::to_string(i) + "', 'STANDARD')";
        }
    }

    // Premium D, E, F
    std::string premRows[] = {"D", "E", "F"};
    for (const auto& r : premRows) {
        for (int i = 1; i <= 6; ++i) {
            seatSql += ", (" + std::to_string(newScreenId) + ", '" + r + "', " + std::to_string(i) + ", '" + r + std::to_string(i) + "', 'PREMIUM')";
        }
    }

    // VIP Row G (10-15)
    for (int i = 10; i <= 15; ++i) {
        seatSql += ", (" + std::to_string(newScreenId) + ", 'G', " + std::to_string(i) + ", 'G" + std::to_string(i) + "', 'VIP')";
    }
    seatSql += ";";

    conn_->execute(seatSql);
    std::cout << "[BookingService] Screen '" << screenName << "' (ID: " << newScreenId << ") created with 24 physical seats in MySQL.\n";
    return true;
}

bool BookingService::addShow(int movieId, int screenId, const std::string& showDateTime, double basePrice, std::string& outError) {
    if (!conn_ || !conn_->isConnected()) {
        outError = "Database offline.";
        return false;
    }

    if (movieId <= 0 || screenId <= 0 || showDateTime.empty()) {
        outError = "Movie, screen, and date/time are required.";
        return false;
    }

    // Collision check: same screen + same show_time
    std::string colCheck = "SELECT show_id FROM shows WHERE screen_id = " + std::to_string(screenId) + " AND show_time = '" + showDateTime + "' LIMIT 1;";
    auto existing = conn_->query(colCheck);
    if (!existing.empty()) {
        outError = "This screen already has a show scheduled at " + showDateTime + ".";
        return false;
    }

    double price = (basePrice > 0) ? basePrice : 350.0;

    std::string insertShow = "INSERT INTO shows (movie_id, screen_id, show_time, base_price, total_seats, available_seats, status) VALUES ("
        + std::to_string(movieId) + ", "
        + std::to_string(screenId) + ", '"
        + showDateTime + "', "
        + std::to_string(price) + ", 24, 24, 'ACTIVE');";

    if (!conn_->execute(insertShow)) {
        outError = "Failed to insert show schedule.";
        return false;
    }

    auto showRows = conn_->query("SELECT show_id FROM shows WHERE screen_id = " + std::to_string(screenId) + " AND show_time = '" + showDateTime + "' LIMIT 1;");
    if (showRows.empty()) {
        outError = "Show created, but unable to locate new show ID.";
        return false;
    }
    int newShowId = std::atoi(showRows[0].get("show_id").c_str());

    // Generate show_seats for all seats on this screen with status AVAILABLE
    std::string genSeats = 
        "INSERT INTO show_seats (show_id, seat_id, price, status) "
        "SELECT " + std::to_string(newShowId) + ", seat_id, "
        "CASE WHEN seat_type = 'VIP' THEN " + std::to_string(price + 100.0) + " "
        "     WHEN seat_type = 'PREMIUM' THEN " + std::to_string(price + 50.0) + " "
        "     ELSE " + std::to_string(price) + " END, "
        "'AVAILABLE' "
        "FROM seats WHERE screen_id = " + std::to_string(screenId) + ";";

    conn_->execute(genSeats);

    // Synchronize show capacity count
    conn_->execute("UPDATE shows SET total_seats = (SELECT COUNT(*) FROM show_seats WHERE show_id = " + std::to_string(newShowId) + "), "
                   "available_seats = (SELECT COUNT(*) FROM show_seats WHERE show_id = " + std::to_string(newShowId) + " AND status = 'AVAILABLE') "
                   "WHERE show_id = " + std::to_string(newShowId) + ";");

    std::cout << "[BookingService] Show #" << newShowId << " scheduled for Screen #" << screenId << " on " << showDateTime << " with show_seats initialized.\n";
    return true;
}

// Legacy fallback methods
BookingResult BookingService::createBooking(const BookingRequest& req) {
    return createPendingReservation(req);
}

bool BookingService::cancelBooking(int bookingId) {
    std::string dummy;
    return cancelBookingByUser(bookingId, 1, dummy);
}

models::Booking BookingService::getBookingById(int bookingId) {
    return getTicketDetails(bookingId, 1, true);
}

std::vector<models::Booking> BookingService::getUserBookings(int userId) {
    return getUserBookingsDetailed(userId);
}

} // namespace booking
} // namespace synccore
