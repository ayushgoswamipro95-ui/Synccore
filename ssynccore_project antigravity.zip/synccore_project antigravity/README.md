# SyncCore — Concurrent Movie Ticket Booking & OS/DBMS Concurrency Simulator

SyncCore is an advanced, production-grade Problem-Based Learning (PBL) project that unites a **Real-World Cinema Ticket Booking Platform** with an interactive **Operating System (OS) & Database Management System (DBMS) Concurrency Simulation Environment**.

Built without heavy full-stack web frameworks, SyncCore leverages high-performance native systems engineering: a **modular C++14 backend** on Windows Winsock2, a **MySQL 8.x InnoDB ACID relational database**, and a **modern Vanilla HTML5/CSS3/ES6 JavaScript frontend** featuring dark glassmorphic design.

---

## 🚀 Key Highlights & New Enhancements

1. **Real Razorpay Payment Gateway Integration**:
   - Secure server-side order creation (`POST /api/payment/create-order`).
   - Official Razorpay Checkout integration with test sandbox support.
   - Server-side cryptographic HMAC-SHA256 signature verification (`POST /api/payment/verify`) and webhook processing (`POST /api/payment/webhook`).
   - Trusted backend pricing calculation (amounts from frontend are never trusted).
   - Zero secrets exposed to the frontend; credentials managed via `.env` (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`).
   - Pessimistic locking: seats are locked during payment and committed upon signature validation, or automatically rolled back on failure/cancellation.

2. **Customer Authentication & Security**:
   - Customer Signup & Login with email validation and normalization (whitespace trimming, case-insensitivity).
   - SHA-256 salted password hashing (`salt$hash`) with zero plain-text password storage.
   - Bearer session token management with thread-safe Windows synchronization.
   - Enforced authentication guards before seat selection, payment, or viewing personal tickets.

3. **Personalized Booking History (`my-bookings.html`)**:
   - Bookings are strictly linked to the authenticated user ID (`user_id`).
   - Normal users only see their own reservation records.
   - 3 categorized views: **Upcoming Bookings**, **Past Bookings**, and **Cancelled Bookings**.
   - Rich booking cards displaying Movie, Poster, Theatre, Screen, Showtime, Seats, Total Amount, Payment Status, and Booking Date.
   - Customer self-service booking cancellation releasing seats back to inventory.

4. **Official Downloadable / Printable Cinema E-Tickets**:
   - Boarding-pass style ticket modal with cinema branding, verified seal, movie poster, and seat badges.
   - Real QR Code generated using an offline-first, zero-dependency engine encoding safe booking references (`BK-XXXXXX`) with zero private user secrets.
   - One-click print/PDF download with dedicated `@media print` stylesheet producing a crisp, clean 1-page admission pass.
   - Admin gate admission verifier (`GET /api/admin/verify-ticket?ref=...`) to validate entry.

5. **Real Show Date Scheduling**:
   - Removed arbitrary free-form `<input type="date">` inputs.
   - Customers select exclusively from actual scheduled screening dates fetched from MySQL.
   - Shows grouped by Theatre, Screen, and Auditorium format (e.g., Laser IMAX, Dolby Atmos).

6. **Admin Theatre & Screen Management**:
   - Multi-screen support per theatre complex with customized auditorium types (`2D`, `3D`, `IMAX`, `4DX`, `Dolby Atmos`).
   - Automatic generation of physical seats (Standard, Premium, VIP) upon screen creation.
   - Show scheduler with schedule collision prevention for overlapping auditoriums and times.
   - Movie management without arbitrary rating input; button labeled strictly `Save Movie`.
   - Complete removal of legacy booking database purge/cleanup feature.

7. **Dual-Engine OS & DBMS Simulator**:
   - Live CPU scheduling simulation comparing **FCFS**, **SJF**, and **Priority** algorithms.
   - Demonstration of Race Conditions with and without mutex synchronization.
   - Wait-For-Graph (WFG) cycle detection using Depth-First Search (DFS) and automated deadlock recovery.
   - Fully functional standalone offline fallback mode when backend is offline.

---

## 📁 Repository Structure

```
SyncCore/
├── .env.example          # Environment variables template (Razorpay keys, MySQL credentials)
├── docs/                 # Architectural specifications, DB models, OS simulation specs, API docs
│   ├── api-documentation.md
│   ├── architecture.md
│   ├── database-design.md
│   └── simulation-design.md
├── frontend/             # Single-Page & Multi-Page views, CSS design system, modular JS components
│   ├── css/              # Global, components, dashboard, ticket, simulation styles
│   ├── js/
│   │   ├── api.js        # Unified REST API client with offline demo fallback
│   │   ├── components/   # Navbar auth modal, ticket generator, qrcode, toast
│   │   ├── booking/      # Show selection, seat layout, payment, booking logic
│   │   └── simulation/   # CPU schedulers, deadlock graph, lock visualizers
│   ├── pages/            # admin.html, booking.html, confirmation.html, my-bookings.html, payment.html, seats.html, shows.html, simulation.html
│   └── index.html        # Cinema storefront homepage
├── backend/              # C++14 modular server: DB layer, OS scheduler, Concurrency, Simulation
│   ├── include/          # Modular header files (.h)
│   │   ├── auth/         # AuthService, UserSession models
│   │   ├── crypto/       # Sha256, HmacSha256, PasswordHash
│   │   ├── payment/      # RazorpayService, OrderResult, VerifyResult
│   │   ├── booking/      # BookingService, SeatService, Multi-screen
│   │   ├── concurrency/  # SyncMutex, SyncLockGuard, RaceSimulator
│   │   ├── deadlock/     # WaitForGraph, DeadlockDetector
│   │   └── simulation/   # CpuScheduler, FCFS, SJF, Priority
│   ├── src/              # C++ implementations (.cpp)
│   └── bin/              # Compiled synccore.exe binary
├── database/             # 12 normalized SQL tables, triggers, views, stored procedures, seed data
│   ├── migrations/       # Schema upgrade scripts (01_upgrade_v2.sql)
│   └── schema.sql        # Core MySQL 8.x DDL
└── scripts/              # Compilation runners and database bootstrap scripts
    ├── compile.bat       # Native MinGW GCC C++14 build script
    └── run-project.bat   # Startup helper
```

---

## ⚙️ Setup & Execution

### 1. Database Configuration
Ensure MySQL Server 8.x is running and execute the schema:
```sql
SOURCE database/schema.sql;
SOURCE database/migrations/01_upgrade_v2.sql;
```

### 2. Environment Variables (.env)
Copy `.env.example` to `.env` and set your credentials:
```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=synccore_db
DB_USER=root
DB_PASS=YourPassword

RAZORPAY_KEY_ID=rzp_test_synccore_demo
RAZORPAY_KEY_SECRET=test_synccore_secret_xyz123
RAZORPAY_WEBHOOK_SECRET=test_webhook_secret_abc456
```

### 3. Compile Backend
Execute the Windows batch compiler:
```cmd
scripts\compile.bat
```

### 4. Start Server
Run the HTTP REST server on port 8080:
```cmd
bin\synccore.exe --server
```

### 5. Launch Frontend
Open `frontend/index.html` in any modern web browser or serve via a lightweight HTTP static server:
```cmd
python -m http.server 3000 --directory frontend
```

---

## 🛡️ ACID Concurrency Guarantees

```
Client Reservation Request
          │
          ▼
Pessimistic Lock (SELECT ... FOR UPDATE)
          │
          ▼
Seats marked 'LOCKED' (10-minute lease)
          │
          ▼
Razorpay Order Generation (Backend Trusted Price)
          │
          ▼
Customer Performs Real Payment
          │
          ▼
Server-Side HMAC-SHA256 Signature Verification
       ┌──┴──┐
    SUCCESS  FAILURE
       │        │
       ▼        ▼
COMMIT Txn   ROLLBACK Txn
Mark BOOKED  Release Locks -> AVAILABLE
Issue Ticket Abort Reservation
```
