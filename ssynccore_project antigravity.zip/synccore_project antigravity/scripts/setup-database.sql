-- SyncCore Master Database Bootstrap Script
-- Run this script in MySQL Workbench or via: mysql -u root -p < scripts/setup-database.sql

CREATE DATABASE IF NOT EXISTS synccore_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE synccore_db;

-- 1. Schema Tables (in strict dependency order)
SOURCE ../database/schema/01_users.sql;
SOURCE ../database/schema/02_movies.sql;
SOURCE ../database/schema/03_theatres.sql;
SOURCE ../database/schema/04_screens.sql;
SOURCE ../database/schema/05_seats.sql;
SOURCE ../database/schema/06_shows.sql;
SOURCE ../database/schema/07_show_seats.sql;
SOURCE ../database/schema/08_bookings.sql;
SOURCE ../database/schema/09_booking_seats.sql;
SOURCE ../database/schema/10_transactions.sql;
SOURCE ../database/schema/11_processes.sql;
SOURCE ../database/schema/12_resource_locks.sql;

-- 2. Triggers
SOURCE ../database/triggers/booking_seat_trigger.sql;
SOURCE ../database/triggers/booking_cancel_trigger.sql;
SOURCE ../database/triggers/seat_count_trigger.sql;

-- 3. Views
SOURCE ../database/views/available_seats_view.sql;
SOURCE ../database/views/booking_details_view.sql;
SOURCE ../database/views/simulation_performance_view.sql;

-- 4. Stored Procedures
SOURCE ../database/procedures/book_seat.sql;
SOURCE ../database/procedures/cancel_booking.sql;
SOURCE ../database/procedures/get_performance.sql;

-- 5. Seed Initial Data
SOURCE ../database/seed/users.sql;
SOURCE ../database/seed/movies.sql;
SOURCE ../database/seed/theatres.sql;
SOURCE ../database/seed/seats.sql;
SOURCE ../database/seed/shows.sql;

SELECT 'SyncCore Database Setup Completed Successfully!' AS status;
