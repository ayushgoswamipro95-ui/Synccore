# SyncCore — Execution & Build Guide

## 1. Prerequisites
- **Compiler**: MinGW GCC 6.3+ (or Clang / MSVC) with C++14 support.
- **Database**: MySQL Server 8.x (optional for Phase 1 local diagnostics mode).
- **Web Browser**: Any modern browser (Chrome, Edge, Firefox).

---

## 2. Compiling the C++ Backend

### Using MinGW GCC (Windows PowerShell or Command Prompt):
From the project root:

```powershell
g++ -std=c++14 -Ibackend/include `
  backend/src/main.cpp `
  backend/src/database/*.cpp `
  backend/src/booking/*.cpp `
  backend/src/transaction/*.cpp `
  backend/src/os/*.cpp `
  backend/src/concurrency/*.cpp `
  backend/src/deadlock/*.cpp `
  backend/src/simulation/*.cpp `
  -lws2_32 -o bin/synccore.exe
```

Or execute the provided batch script:
```powershell
.\scripts\compile.bat
```

---

## 3. Running the Backend

### Diagnostic CLI Mode:
Runs internal kernel, scheduler, race condition, and deadlock diagnostics:
```powershell
.\bin\synccore.exe
```

### HTTP Server Mode:
Listens on `http://localhost:8080` for API calls:
```powershell
.\bin\synccore.exe --server
```

---

## 4. Running the Frontend
Simply open `frontend/index.html` in your web browser:
```powershell
start frontend/index.html
```

Or navigate through:
- Cinema Booking: `frontend/pages/home.html`
- Concurrency Lab: `frontend/pages/simulation.html`

---

## 5. Setting up the MySQL Database
When you are ready to connect to a live MySQL instance:
1. Open MySQL Command Line or Workbench.
2. Run:
```sql
source scripts/setup-database.sql;
```
This will automatically construct all 12 tables, triggers, views, and seed data.
