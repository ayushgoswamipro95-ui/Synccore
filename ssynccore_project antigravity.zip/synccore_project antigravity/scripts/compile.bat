@echo off
echo ===============================================================
echo   Compiling SyncCore Modular C++ Backend
echo ===============================================================

if not exist bin mkdir bin

g++ -std=c++14 -O2 -Ibackend/include ^
    backend/src/main.cpp ^
    backend/src/auth/AuthService.cpp ^
    backend/src/payment/RazorpayService.cpp ^
    backend/src/database/DatabaseConnection.cpp ^
    backend/src/database/QueryExecutor.cpp ^
    backend/src/database/TransactionManager.cpp ^
    backend/src/booking/BookingService.cpp ^
    backend/src/booking/SeatService.cpp ^
    backend/src/booking/PaymentService.cpp ^
    backend/src/transaction/TransactionService.cpp ^
    backend/src/transaction/CommitManager.cpp ^
    backend/src/transaction/RollbackManager.cpp ^
    backend/src/os/Process.cpp ^
    backend/src/os/ProcessManager.cpp ^
    backend/src/os/ReadyQueue.cpp ^
    backend/src/os/FCFSScheduler.cpp ^
    backend/src/os/SJFScheduler.cpp ^
    backend/src/os/PriorityScheduler.cpp ^
    backend/src/os/SchedulerManager.cpp ^
    backend/src/concurrency/MutexManager.cpp ^
    backend/src/concurrency/SemaphoreManager.cpp ^
    backend/src/concurrency/CriticalSection.cpp ^
    backend/src/concurrency/LockManager.cpp ^
    backend/src/concurrency/RaceConditionSimulator.cpp ^
    backend/src/deadlock/DeadlockDetector.cpp ^
    backend/src/deadlock/DeadlockSimulator.cpp ^
    backend/src/simulation/SimulationEngine.cpp ^
    backend/src/simulation/VirtualUser.cpp ^
    backend/src/simulation/SimulationResult.cpp ^
    backend/src/simulation/PerformanceAnalyzer.cpp ^
    -lws2_32 -o bin\synccore.exe

if %ERRORLEVEL% EQU 0 (
    echo [SUCCESS] Compilation completed: bin\synccore.exe
) else (
    echo [ERROR] Compilation failed!
)
